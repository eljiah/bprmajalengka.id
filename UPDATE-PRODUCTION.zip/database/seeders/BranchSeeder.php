<?php

namespace Database\Seeders;

use App\Models\Branch;
use Illuminate\Database\Seeder;

class BranchSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Branch::whereIn('name', [
            'Kantor Kas Kadipaten',
            'Kantor Kas Jatiwangi',
            'Kantor Kas Talaga',
            'Kantor Kas Cikijing',
            'Kantor Kas Rajagaluh',
            'Kantor Kas Leuwimunding',
            'Kantor Kas Sukahaji',
            'Kantor Kas Maja',
            'Kantor Kas Kertajati',
            'Kantor Kas Ligung',
            'Kantor Kas Sumberjaya',
        ])->update(['is_active' => false]);

        $branches = [
            [
                'name' => 'Kantor Pusat Operasional',
                'type' => 'Pusat',
                'address' => 'Jl. Raya K.H. Abdul Halim No. 338, Majalengka Wetan, Kec. Majalengka, Jawa Barat 45411',
                'phone' => '(0233) 281144',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => true,
                'sort_order' => 1,
            ],
            [
                'name' => 'Kantor Cabang Kadipaten',
                'type' => 'Cabang',
                'address' => 'Jl. Raya Kadipaten No. 45, Kec. Kadipaten (Dekat Pasar Kadipaten)',
                'maps_url' => 'https://maps.app.goo.gl/m1WY5x3bvt2rf74Z7',
                'latitude' => '-6.7632246516128065',
                'longitude' => '108.1682402947551',
                'phone' => '(0233) 282510',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 2,
            ],
            [
                'name' => 'Kantor Cabang Jatitujuh',
                'type' => 'Cabang',
                'address' => 'Jl. Raya Utara No.113 Jatitujuh',
                'maps_url' => 'https://www.google.com/maps?q=-6.6439472368882635,108.2294895625247',
                'latitude' => '-6.6439472368882635',
                'longitude' => '108.2294895625247',
                'phone' => '(0233) 8888211',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 3,
            ],
            [
                'name' => 'Kantor Cabang Cikijing',
                'type' => 'Cabang',
                'address' => 'Jl. Raya Kasturi No. 15, Kec. Cikijing (Pusat Konveksi Celana Jeans)',
                'maps_url' => 'https://maps.app.goo.gl/65yBz4rkPUPPYpBc9',
                'latitude' => '-7.016916098244055',
                'longitude' => '108.36454874491558',
                'phone' => '(0233) 891340',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 4,
            ],
            [
                'name' => 'Kantor Cabang Rajagaluh',
                'type' => 'Cabang',
                'address' => 'Jl. Pangeran Muhamad No. 34, Kec. Rajagaluh (Sentra Anyaman Bambu)',
                'maps_url' => 'https://maps.app.goo.gl/dzKqbWBpxUZiqkR37',
                'latitude' => '-6.779398593568954',
                'longitude' => '108.3447027455341',
                'phone' => '(0233) 511450',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 5,
            ],
            [
                'name' => 'Kantor Cabang Bantarujeg',
                'type' => 'Cabang',
                'address' => 'Jl. Siliwangi No.91 Bantarujeg',
                'maps_url' => 'https://maps.app.goo.gl/cRU3vjddyqW6uQx38',
                'latitude' => '-6.968736619525069',
                'longitude' => '108.23936331773582',
                'phone' => '(0233) 8316346',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 6,
            ],
            [
                'name' => 'Kantor Cabang Sukahaji',
                'type' => 'Cabang',
                'address' => 'Jl. Raya Sukahaji No. 10, Cikalong, Kec. Sukahaji',
                'maps_url' => 'https://maps.app.goo.gl/FUDyUFCGK9qBppsJ7',
                'latitude' => '-6.8190775141653255',
                'longitude' => '108.2807762434407',
                'phone' => '(0233) 882190',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 7,
            ],
            [
                'name' => 'Kantor Cabang Kertajati',
                'type' => 'Cabang',
                'address' => 'Jl. Kertajati-Kadipaten Km 3, Kec. Kertajati (Kawasan Bandara Internasional Kertajati)',
                'maps_url' => 'https://maps.app.goo.gl/oDvA7PDcnVTPNZWi7',
                'latitude' => '-6.677310235565713',
                'longitude' => '108.1890547352578',
                'phone' => '(0233) 883100',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 8,
            ],
            [
                'name' => 'Kantor Cabang Ligung',
                'type' => 'Cabang',
                'address' => 'Jl. Raya Ligung No. 78, Kec. Ligung (Sentra Industri Pabrik)',
                'maps_url' => 'https://maps.app.goo.gl/vezobnU4cMSMgH7L6',
                'latitude' => '-6.652526614832701',
                'longitude' => '108.28211492563509',
                'phone' => '(0233) 884520',
                'whatsapp' => '0811-1111-6526',
                'hours' => 'Senin - Jumat: 08:00 - 15:30 WIB',
                'is_main' => false,
                'sort_order' => 9,
            ],
        ];

        foreach ($branches as $branch) {
            $branch['is_active'] = true;
            Branch::updateOrCreate(
                ['name' => $branch['name']],
                $branch
            );
        }
    }
}
