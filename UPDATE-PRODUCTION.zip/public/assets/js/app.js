/**
 * Bank Majalengka - Frontend Application Script
 * Mengacu pada Sketsa Mockup (13 Halaman) dan Figma Corporate UI Design
 */

var currentComplaintLocalAnswer = 13;

function bootstrapApp() {
  if (window.DYNAMIC_PRODUCTS) {
    if (window.DYNAMIC_PRODUCTS.tabungan) PRODUCTS_DATA.tabungan = window.DYNAMIC_PRODUCTS.tabungan;
    if (window.DYNAMIC_PRODUCTS.deposito) PRODUCTS_DATA.deposito = window.DYNAMIC_PRODUCTS.deposito;
    if (window.DYNAMIC_PRODUCTS.kredit) PRODUCTS_DATA.kredit = window.DYNAMIC_PRODUCTS.kredit;
  }
  if (window.DYNAMIC_BRANCHES && Array.isArray(window.DYNAMIC_BRANCHES)) {
    BRANCHES_DATA.length = 0;
    BRANCHES_DATA.push(...window.DYNAMIC_BRANCHES);
  }
  if (window.DYNAMIC_ARTICLES && Array.isArray(window.DYNAMIC_ARTICLES)) {
    ARTICLES_DATA.length = 0;
    ARTICLES_DATA.push(...window.DYNAMIC_ARTICLES);
  }

  try { initNavbar(); } catch (e) { console.warn('initNavbar error:', e); }
  try { initKolomTanya(); } catch (e) { console.warn('initKolomTanya error:', e); }
  try { initHeroCarousel(); } catch (e) { console.warn('initHeroCarousel error:', e); }
  try { initProductShowcase(); } catch (e) { console.warn('initProductShowcase error:', e); }
  try { initSimulator(); } catch (e) { console.warn('initSimulator error:', e); }
  try { initFormPengajuan(); } catch (e) { console.warn('initFormPengajuan error:', e); }
  try { initPengaduanNasabah(); } catch (e) { console.warn('initPengaduanNasabah error:', e); }
  try { initProductModals(); } catch (e) { console.warn('initProductModals error:', e); }
  try { initNewsModal(); } catch (e) { console.warn('initNewsModal error:', e); }
  try { initFAQ(); } catch (e) { console.warn('initFAQ error:', e); }
  try { initKantorKas(); } catch (e) { console.warn('initKantorKas error:', e); }
  try { initLaporanPublikasi(); } catch (e) { console.warn('initLaporanPublikasi error:', e); }
  try { initGlobalModals(); } catch (e) { console.warn('initGlobalModals error:', e); }
  try { initFraudWarningModal(); } catch (e) { console.warn('initFraudWarningModal error:', e); }
  try { openActivePublicPage(); } catch (e) { console.warn('openActivePublicPage error:', e); }
}

function openActivePublicPage() {
  const activePage = document.body.dataset.activePage;

  if (activePage === 'pengaduan') {
    document.getElementById('pengaduan-nasabah')?.scrollIntoView();
  } else if (activePage === 'pengajuan-kredit') {
    openFormPengajuan();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrapApp);
} else {
  bootstrapApp();
}

// Global Function Declarations & Exposures (Strictly matching Mockup Sketches and BCA Product Showcase)
function resolveProduct(product) {
  if (!product) return null;
  if (typeof product === 'object') return product;
  const searchKey = String(product).toLowerCase().trim();
  for (const cat of ['tabungan', 'deposito', 'kredit']) {
    const list = PRODUCTS_DATA[cat] || [];
    const found = list.find(p => {
      const codeMatch = p.code && p.code.toLowerCase() === searchKey;
      const idMatch = p.id && String(p.id).toLowerCase() === searchKey;
      const slugMatch = p.slug && p.slug.toLowerCase() === searchKey;
      const nameMatch = p.name && p.name.toLowerCase() === searchKey;
      return codeMatch || idMatch || slugMatch || nameMatch;
    });
    if (found) return found;
  }
  return null;
}

let currentCatalogCategory = 'all';

function showProductDetail(product) {
  const prod = resolveProduct(product);
  const detailModal = document.getElementById('modal-product-detail');
  if (!detailModal || !prod) return;

  const shortDesc = prod.shortDesc || prod.short_desc || '';
  const heroImage = prod.heroImage || prod.hero_image || 'assets/img/hero-batik.jpg';
  const ctaText = prod.ctaText || prod.cta_text || (prod.category === 'kredit' ? 'Form Pengajuan Kredit' : 'Buka Rekening via WhatsApp');
  const ctaType = prod.ctaType || prod.cta_type || (prod.category === 'kredit' ? 'form' : 'whatsapp');
  const ketentuanList = Array.isArray(prod.ketentuan) ? prod.ketentuan : [];
  const syaratList = Array.isArray(prod.syarat) ? prod.syarat : [];

  const tEl = document.getElementById('detail-product-title'); if (tEl) tEl.textContent = prod.name || '';
  const bEl = document.getElementById('detail-product-badge'); if (bEl) bEl.textContent = prod.badge || prod.code || '';
  const htEl = document.getElementById('detail-product-hero-title'); if (htEl) htEl.textContent = prod.name || '';
  const sEl = document.getElementById('detail-product-slogan'); if (sEl) sEl.textContent = prod.slogan || '';
  const dEl = document.getElementById('detail-product-short-desc'); if (dEl) dEl.textContent = shortDesc;
  const hiEl = document.getElementById('detail-product-hero-img'); if (hiEl) hiEl.src = heroImage;

  const defaultWa = '6281111116526';
  const waOfficial = (window.DYNAMIC_SETTINGS && window.DYNAMIC_SETTINGS.whatsapp_official ? window.DYNAMIC_SETTINGS.whatsapp_official : defaultWa).replace(/[^0-9]/g, '');

  const heroCta = document.getElementById('detail-product-hero-cta');
  if (heroCta) {
    if (prod.category === 'kredit' || ctaType === 'form' || ctaType === 'form_pengajuan') {
      heroCta.classList.remove('hidden');
      heroCta.innerHTML = `
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
        <span>Form Pengajuan Kredit</span>
      `;
      heroCta.onclick = () => {
        detailModal.classList.remove('active');
        const catModal = document.getElementById('modal-product-catalog');
        if (catModal) catModal.classList.remove('active');
        openFormPengajuan(null, null, prod.name);
      };
    } else {
      heroCta.classList.remove('hidden');
      heroCta.innerHTML = `
        <svg class="w-4 h-4 fill-current text-emerald-400" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z"/></svg>
        <span>Buka Rekening via WhatsApp</span>
      `;
      const waMsg = encodeURIComponent(`Halo Perumda BPR Majalengka, saya tertarik untuk membuka rekening / informasi produk ${prod.name} (${prod.code}). Mohon bantuannya.`);
      heroCta.onclick = () => {
        window.open(`https://wa.me/${waOfficial}?text=${waMsg}`, '_blank');
      };
    }
  }

  const ketContainer = document.getElementById('detail-product-ketentuan');
  if (ketContainer) {
    ketContainer.innerHTML = ketentuanList.map(item => `
      <li class="flex items-start gap-2.5 text-sm text-slate-700 leading-relaxed">
        <span class="w-1.5 h-1.5 rounded-full bg-bpr-blue mt-2 flex-shrink-0"></span>
        <span>${item}</span>
      </li>
    `).join('');
  }

  const syrContainer = document.getElementById('detail-product-syarat');
  if (syrContainer) {
    syrContainer.innerHTML = syaratList.map(item => `
      <li class="flex items-start gap-2.5 text-sm text-slate-700 leading-relaxed">
        <span class="w-1.5 h-1.5 rounded-full bg-bpr-gold mt-2 flex-shrink-0"></span>
        <span>${item}</span>
      </li>
    `).join('');
  }

  const ctaBtn = document.getElementById('detail-product-cta-btn');
  if (ctaBtn) {
    ctaBtn.textContent = ctaText;
    if (prod.category === 'kredit' || ctaType === 'form' || ctaType === 'form_pengajuan') {
      ctaBtn.onclick = () => {
        detailModal.classList.remove('active');
        const catModal = document.getElementById('modal-product-catalog');
        if (catModal) catModal.classList.remove('active');
        openFormPengajuan(null, null, prod.name);
      };
    } else {
      const waMsg = encodeURIComponent(`Halo Perumda BPR Majalengka, saya tertarik untuk membuka / konsultasi produk ${prod.name} (${prod.code}). Mohon info jadwal dan syarat pendaftarannya.`);
      ctaBtn.onclick = () => {
        window.open(`https://wa.me/${waOfficial}?text=${waMsg}`, '_blank');
      };
    }
  }

  detailModal.classList.add('active');
  document.body.classList.add('overflow-hidden');
}

function renderCatalogCards(category = 'all', filterText = '') {
  const container = document.getElementById('catalog-cards-container');
  if (!container) return;

  let allItems = [];
  if (category === 'all' || category === 'tabungan') allItems.push(...PRODUCTS_DATA.tabungan);
  if (category === 'all' || category === 'deposito') allItems.push(...PRODUCTS_DATA.deposito);
  if (category === 'all' || category === 'kredit') allItems.push(...PRODUCTS_DATA.kredit);

  if (filterText) {
    const q = filterText.toLowerCase();
    allItems = allItems.filter(item => 
      (item.name || '').toLowerCase().includes(q) || 
      ((item.shortDesc || item.short_desc) || '').toLowerCase().includes(q) ||
      (item.code || '').toLowerCase().includes(q)
    );
  }

  if (allItems.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-12 text-center text-slate-500">
        <svg class="w-12 h-12 mx-auto mb-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <p class="font-semibold">Produk tidak ditemukan</p>
        <p class="text-sm">Silakan ubah kata kunci pencarian atau ganti kategori produk.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = allItems.map(prod => `
    <div onclick="window.catalogModalCardClick && window.catalogModalCardClick('${prod.code}')" class="bg-white rounded-2xl p-6 card-shadow card-shadow-hover flex flex-col justify-between cursor-pointer group">
      <div>
        <div class="flex items-center justify-between mb-3">
          <span class="text-xs font-bold px-2.5 py-1 rounded-lg ${prod.category === 'tabungan' ? 'bg-blue-50 text-bpr-blue font-semibold' : prod.category === 'deposito' ? 'bg-amber-50 text-amber-700 font-semibold' : 'bg-emerald-50 text-emerald-700 font-semibold'}">${prod.badge || (prod.category === 'tabungan' ? 'Tabungan' : prod.category === 'deposito' ? 'Deposito' : 'Kredit')}</span>
          <span class="text-xs text-slate-400 font-mono">${prod.code}</span>
        </div>
        <div class="h-32 rounded-xl bg-slate-50 flex items-center justify-center p-3 mb-4 overflow-hidden group-hover:scale-[1.02] transition-transform">
          <img src="${prod.image}" alt="${prod.name}" class="max-h-full max-w-full object-contain" onerror="this.src='assets/img/logo.png'">
        </div>
        <h4 class="font-bold text-slate-900 group-hover:text-bpr-blue transition-colors text-base mb-1.5 leading-snug">${prod.name}</h4>
        <p class="text-slate-500 text-xs line-clamp-3 mb-4 leading-relaxed">${prod.shortDesc || prod.short_desc || ''}</p>
      </div>
      <div class="pt-3 mt-auto flex items-center justify-between">
        <span class="text-xs font-semibold text-bpr-blue group-hover:underline">
          Selengkapnya
        </span>
        <span class="text-xs text-slate-400 font-medium">BPR Majalengka</span>
      </div>
    </div>
  `).join('');
}

window.catalogModalCardClick = function(code) {
  const modal = document.getElementById('modal-product-catalog');
  if (modal) modal.classList.add('was-open');
  showProductDetail(code);
};

function openProductCatalog(category = 'all') {
  currentCatalogCategory = category;
  const modal = document.getElementById('modal-product-catalog');
  if (!modal) return;

  const tabButtons = document.querySelectorAll('.catalog-tab-btn');
  tabButtons.forEach(btn => {
    if (btn.dataset.category === category) {
      btn.classList.add('bg-bpr-navy', 'text-white');
      btn.classList.remove('bg-slate-100', 'text-slate-600');
    } else {
      btn.classList.remove('bg-bpr-navy', 'text-white');
      btn.classList.add('bg-slate-100', 'text-slate-600');
    }
  });

  const searchInput = document.getElementById('catalog-search-input');
  if (searchInput) searchInput.value = '';

  renderCatalogCards(category, '');

  modal.classList.add('active');
  document.body.classList.add('overflow-hidden');
}

function readArticle(id) {
  const modal = document.getElementById('modal-news-reader');
  if (!modal) return;
  const article = ARTICLES_DATA.find(a => a.id == id || a.slug === id);
  if (!article) return;

  const articleDate = article.date || (article.published_at ? new Date(article.published_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '');
  const articleReadTime = article.readTime || article.read_time || '3 menit baca';

  const tagEl = document.getElementById('news-modal-tag'); if (tagEl) tagEl.textContent = article.tag || article.category || 'Berita';
  const titleEl = document.getElementById('news-modal-title'); if (titleEl) titleEl.textContent = article.title;
  const dateEl = document.getElementById('news-modal-date'); if (dateEl) dateEl.textContent = `${articleDate} • ${articleReadTime}`;
  const imgEl = document.getElementById('news-modal-img'); if (imgEl) imgEl.src = article.image || 'assets/img/perencanaan-keluarga.jpg';
  const bodyEl = document.getElementById('news-modal-body'); if (bodyEl) bodyEl.innerHTML = article.content;

  modal.classList.add('active');
  document.body.classList.add('overflow-hidden');
}

function showAllArticles() {
  const modal = document.getElementById('modal-all-news');
  if (modal) {
    modal.classList.add('active');
    document.body.classList.add('overflow-hidden');
  }
}

function resetProductFilter() {
  if (typeof window.applyShowcaseCategoryTab === 'function') {
    window.applyShowcaseCategoryTab('all', true);
  }
}

function filterProductShowcase(category = 'all') {
  if (typeof window.applyShowcaseCategoryTab === 'function') {
    window.applyShowcaseCategoryTab(category);
  }
}

// Explicit top-level global exposures to guarantee availability across ES module scopes
window.openFormPengajuan = openFormPengajuan;
window.showPengajuanSuccessModal = showPengajuanSuccessModal;
window.openProfilBpr = openProfilBpr;
window.openContactOptions = openContactOptions;
window.openProductCatalog = openProductCatalog;
window.showProductDetail = showProductDetail;
window.readArticle = readArticle;
window.showAllArticles = showAllArticles;
window.resetProductFilter = resetProductFilter;
window.filterProductShowcase = filterProductShowcase;
window.toggleBranchesDirectory = toggleBranchesDirectory;
window.initHeroCarousel = initHeroCarousel;
window.openReportArchive = openReportArchive;
window.closeReportArchiveModal = closeReportArchiveModal;
window.selectReportArchiveFile = selectReportArchiveFile;
window.filterReportArchiveYear = filterReportArchiveYear;
window.switchComplaintTab = switchComplaintTab;
window.copyComplaintCode = copyComplaintCode;
window.resetComplaintForm = resetComplaintForm;
window.checkStatusFromCode = checkStatusFromCode;
window.handleCekStatusSubmit = handleCekStatusSubmit;
window.refreshComplaintCaptcha = refreshComplaintCaptcha;

/* ==========================================================================
   1. DATABASE PRODUK (TABUNGAN, DEPOSITO, KREDIT)
   ========================================================================== */
const PRODUCTS_DATA = {
  tabungan: [
    {
      id: 'tahara',
      code: 'TAB-01',
      name: 'Tabungan Hari Raya (TAHARA)',
      badge: 'Favorit Keluarga',
      category: 'tabungan',
      image: 'assets/img/produk/tahara.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Persiapan menyambut hari raya Idul Fitri yang tenang, khidmat, dan penuh berkah.',
      shortDesc: 'Tabungan berencana dengan setoran bulanan tetap untuk persiapan kebutuhan hari raya Idul Fitri keluarga, mudik, dan parcel lebaran tanpa membebani arus kas bulanan.',
      ketentuan: [
        'Jangka waktu penempatan 10 s/d 12 bulan (pencairan menjelang Idul Fitri).',
        'Setoran bulanan terjangkau mulai dari Rp 50.000,- hingga Rp 5.000.000,- per bulan.',
        'Suku bunga kompetitif di atas tabungan reguler dan bebas biaya administrasi bulanan.',
        'Dana tidak dapat ditarik sebelum jatuh tempo demi kedisiplinan rencana ibadah.',
        'Dijamin sepenuhnya oleh Lembaga Penjamin Simpanan (LPS) hingga Rp 2 Miliar.'
      ],
      syarat: [
        'Fotokopi KTP / Identitas diri pemohon yang masih berlaku (Majalengka/Jawa Barat).',
        'Mengisi dan menandatangani formulir pembukaan rekening TAHARA.',
        'Menyetorkan setoran awal paket pertama sesuai nominal rencana yang dipilih.',
        'Menyertakan nomor WhatsApp aktif untuk konfirmasi mutasi bulanan.'
      ],
      ctaText: 'Buka Rekening TAHARA',
      ctaType: 'whatsapp'
    },
    {
      id: 'tiara',
      code: 'TAB-02',
      name: 'Tabungan Idul Adha (TIARA)',
      badge: 'Ibadah Terencana',
      category: 'tabungan',
      image: 'assets/img/produk/design_tabungan_tapaqur-removebg-preview.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Wujudkan niat suci ibadah qurban setiap tahun dengan angsuran ringan teratur.',
      shortDesc: 'Fasilitas tabungan terencana bagi individu, keluarga, maupun jamaah masjid untuk pengadaan hewan qurban sapi atau kambing saat Idul Adha.',
      ketentuan: [
        'Jangka waktu simpanan fleksibel 12 bulan mengacu pada kalender Hijriah.',
        'Pilihan paket tabungan setara nilai 1 ekor kambing atau 1/7 bagian sapi.',
        'Bebas biaya pemeliharaan rekening bulanan.',
        'Dapat disalurkan langsung melalui panitia kurban mitra BPR Majalengka atau dicairkan tunai.',
        'Aman dan dijamin 100% oleh LPS.'
      ],
      syarat: [
        'Fotokopi KTP/e-KTP pemohon yang masih berlaku.',
        'Mengisi formulir permohonan pembukaan rekening TIARA.',
        'Setoran awal ringan mulai Rp 100.000,-.',
        'Kartu Keluarga (jika atas nama perwakilan keluarga).'
      ],
      ctaText: 'Daftar Tabungan TIARA',
      ctaType: 'whatsapp'
    },
    {
      id: 'kotak-mas',
      code: 'TAB-03',
      name: 'Tabungan KOTAK MAS',
      badge: 'Berhadiah Langsung',
      category: 'tabungan',
      image: 'assets/img/produk/IMG_2909.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Kotak masa depan sejahtera dengan bunga optimal dan bonus hadiah peralatan usaha.',
      shortDesc: 'Program tabungan spesial dengan saldo mengendap berhadiah langsung peralatan elektronik, peralatan usaha, atau logam mulia tanpa diundi.',
      ketentuan: [
        'Komitmen saldo mengendap dengan pilihan periode 1, 2, atau 3 tahun.',
        'Hadiah langsung diserahkan di awal pembukaan rekening sesuai tier saldo.',
        'Bunga tabungan tetap dibayarkan setiap bulan masuk ke rekening utama.',
        'Tersedia untuk nasabah perorangan maupun lembaga swasta daerah.',
        'Simpanan dijamin LPS sesuai ketentuan yang berlaku.'
      ],
      syarat: [
        'e-KTP asli & fotokopi pemohon.',
        'NPWP (apabila ada).',
        'Menandatangani surat perjanjian komitmen program KOTAK MAS.',
        'Penempatan saldo awal sesuai paket hadiah yang dipilih.'
      ],
      ctaText: 'Pilih Hadiah KOTAK MAS',
      ctaType: 'whatsapp'
    },
    {
      id: 'sidasi',
      code: 'TAB-04',
      name: 'Simpanan Dana Siaga (SIDASI)',
      badge: 'Fleksibel Likuid',
      category: 'tabungan',
      image: 'assets/img/produk/IMG_2911.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Dana darurat keluarga yang likuid, aman, dan siap ditarik kapan saja dibutuhkan.',
      shortDesc: 'Tabungan reguler serbaguna dengan perhitungan bunga harian. Setoran dan penarikan sangat mudah dilayani di seluruh 12 jaringan kantor kas dan via Pickup Service.',
      ketentuan: [
        'Bebas setor dan tarik setiap hari kerja di semua kantor kas BPR Majalengka.',
        'Tersedia layanan jemput tabungan langsung ke toko/rumah nasabah.',
        'Perhitungan bunga harian dihitung berdasarkan saldo harian efektif.',
        'Bebas biaya administrasi bulanan untuk saldo di atas ambang minimal.',
        'Dijamin LPS hingga Rp 2 Miliar.'
      ],
      syarat: [
        'Fotokopi KTP / SIM yang masih berlaku.',
        'Mengisi formulir pembukaan rekening perorangan.',
        'Setoran awal sangat ringan, mulai Rp 20.000,-.',
        'Setoran lanjutan minimal Rp 10.000,-.'
      ],
      ctaText: 'Buka Simpanan SIDASI',
      ctaType: 'whatsapp'
    },
    {
      id: 'tapa-qur',
      code: 'TAB-05',
      name: 'Tabungan Paket Qurban (TAPA QUR)',
      badge: 'Kolektif & Masjid',
      category: 'tabungan',
      image: 'assets/img/produk/design_tabungan_tapaqur-removebg-preview.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Kolektif qurban masjid, komunitas, dan rukun warga yang tertib dan transparan.',
      shortDesc: 'Fasilitas tabungan qurban kolektif untuk DKM masjid, majelis taklim, instansi kantor, dan kelompok masyarakat dengan pelaporan berkala transparan.',
      ketentuan: [
        'Dapat dibuka atas nama bendahara panitia qurban masjid atau kelompok per 7 orang.',
        'Laporan rekapitulasi mutasi dapat dicetak sewaktu-waktu untuk pengurus.',
        'Kerjasama resmi dengan peternak lokal Majalengka bersertifikasi kesehatan dinas.',
        'Bebas biaya administrasi dan bebas biaya transfer antar kantor kas BPR.',
        'Dijamin penuh oleh LPS.'
      ],
      syarat: [
        'Fotokopi KTP pengurus (Ketua & Bendahara DKM/Komunitas).',
        'Surat penunjukan kepengurusan DKM atau berita acara kelompok.',
        'Setoran awal kelompok mulai Rp 100.000,-.'
      ],
      ctaText: 'Daftar Paket TAPA QUR',
      ctaType: 'whatsapp'
    },
    {
      id: 'tada-bur',
      code: 'TAB-06',
      name: 'Tabungan Pelajar (TADA BUR)',
      badge: 'Generasi Cerdas',
      category: 'tabungan',
      image: 'assets/img/produk/tadabur.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Membentuk karakter gemar menabung dan kemandirian finansial sejak dini.',
      shortDesc: 'Tabungan khusus siswa PAUD, SD, SMP, hingga SMA di Kabupaten Majalengka dengan buku tabungan atas nama siswa sendiri didampingi orang tua.',
      ketentuan: [
        'Buku tabungan resmi bertuliskan nama siswa pemegang rekening.',
        'Bebas biaya administrasi bulanan seumur hidup siswa.',
        'Kemudahan jemput setoran rutin ke sekolah-sekolah yang bekerjasama.',
        'Sertifikat apresiasi penabung cilik berprestasi setiap akhir tahun ajaran.',
        'Dijamin aman oleh LPS.'
      ],
      syarat: [
        'Fotokopi Kartu Pelajar / Kartu Identitas Anak (KIA) / Akta Kelahiran.',
        'Fotokopi KTP salah satu orang tua / wali.',
        'Fotokopi Kartu Keluarga.',
        'Setoran awal sangat terjangkau hanya Rp 10.000,-.'
      ],
      ctaText: 'Buka Tabungan TADA BUR',
      ctaType: 'whatsapp'
    },
    {
      id: 't-askara',
      code: 'TAB-07',
      name: 'Tabungan T-ASKARA',
      badge: 'Aparatur Desa',
      category: 'tabungan',
      image: 'assets/img/produk/IMG_2914.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Kesejahteraan dan ketahanan masa depan bagi pamong desa dan RT/RW Majalengka.',
      shortDesc: 'Fasilitas tabungan terintegrasi untuk penerimaan tunjangan, siltap, dan insentif perangkat desa serta pengurus lingkungan RT/RW se-Kabupaten Majalengka.',
      ketentuan: [
        'Terhubung langsung dengan mekanisme penyaluran siltap desa.',
        'Kemudahan fasilitas auto-debet untuk tabungan persiapan purna jabatan.',
        'Bebas biaya administrasi pengelolaan rekening.',
        'Akses prioritas pada fasilitas pembiayaan kredit lunak BPR Majalengka.',
        'Dijamin LPS.'
      ],
      syarat: [
        'Fotokopi KTP / e-KTP pamong desa atau pengurus RT/RW.',
        'Salinan Surat Keputusan (SK) Pengangkatan yang masih berlaku.',
        'Surat rekomendasi dari Kepala Desa / Kelurahan setempat.',
        'Setoran awal Rp 50.000,-.'
      ],
      ctaText: 'Informasi T-ASKARA',
      ctaType: 'whatsapp'
    },
    {
      id: 'ciremaiku',
      code: 'TAB-08',
      name: 'Tabungan CIREMAIKU',
      badge: 'Wisata Lokal',
      category: 'tabungan',
      image: 'assets/img/produk/IMG_2922.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Rencanakan liburan indah bersama keluarga menjelajahi eksotisme Tanah Sindangkasih.',
      shortDesc: 'Tabungan tematik wisata untuk merencanakan liburan keluarga di destinasi unggulan Majalengka (Terasering Panyaweuyan, Curug Muara Jaya, Situ Cipanten) dengan bonus voucher tiket masuk.',
      ketentuan: [
        'Target menabung fleksibel 6 s/d 12 bulan.',
        'Mendapatkan voucher diskon tiket masuk objek wisata mitra BPR Majalengka.',
        'Bebas biaya penarikan saat target waktu liburan tiba.',
        'Suku bunga menarik dan terproteksi penjaminan LPS.',
        'Setoran dapat diatur secara harian, mingguan, atau bulanan.'
      ],
      syarat: [
        'Fotokopi KTP pemohon.',
        'Mengisi form pembukaan rekening CIREMAIKU.',
        'Setoran awal mulai Rp 50.000,-.'
      ],
      ctaText: 'Mulai Tabungan Wisata',
      ctaType: 'whatsapp'
    },
    {
      id: 'simpel',
      code: 'TAB-09',
      name: 'Simpanan Pelajar (SimPel) OJK',
      badge: 'Program Nasional',
      category: 'tabungan',
      image: 'assets/img/produk/tadabur.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Gerakan Indonesia Menabung resmi berstandar Otoritas Jasa Keuangan (OJK).',
      shortDesc: 'Produk tabungan nasional inisiasi OJK khusus siswa PAUD s/d SMA dengan fitur serba sederhana, syarat mudah, dan bebas biaya admin bulanan.',
      ketentuan: [
        'Bebas biaya administrasi bulanan.',
        'Setoran awal hanya Rp 5.000,- dan setoran berikutnya mulai Rp 1.000,-.',
        'Buku tabungan diterbitkan langsung atas nama siswa.',
        'Dilindungi penuh oleh Lembaga Penjamin Simpanan (LPS).'
      ],
      syarat: [
        'Fotokopi Kartu Pelajar / Surat Keterangan Sekolah.',
        'Fotokopi Akta Kelahiran dan Kartu Keluarga.',
        'Fotokopi KTP orang tua / wali.',
        'Mengisi formulir pembukaan SimPel di loket atau saat mobil kas keliling ke sekolah.'
      ],
      ctaText: 'Buka Rekening SimPel',
      ctaType: 'whatsapp'
    },
    {
      id: 'simarmas-co',
      code: 'TAB-10',
      name: 'SIMARMAS GO (Mitra Karyawan)',
      badge: 'Payroll Industri',
      category: 'tabungan',
      image: 'assets/img/produk/IMG_2926.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Layanan payroll dan tabungan kolektif pekerja industri manufaktur Majalengka.',
      shortDesc: 'Solusi pembayaran upah kerja (payroll) dan simpanan terencana bagi para karyawan pabrik garmen, industri aviasi Kertajati, dan perusahaan swasta di Majalengka.',
      ketentuan: [
        'Penyaluran gaji tepat waktu zero-fee transfer.',
        'Fasilitas penarikan tunai mudah di seluruh jaringan kantor kas.',
        'Kemudahan pengajuan kredit pegawai (KAPESTA) dengan proses satu pintu.',
        'Dijamin aman oleh LPS hingga Rp 2 Miliar per nasabah.'
      ],
      syarat: [
        'Perjanjian Kerjasama (PKS) antara perusahaan/HRD dengan BPR Majalengka.',
        'Fotokopi KTP dan ID Card Karyawan.',
        'Daftar nominatif karyawan dari perusahaan.'
      ],
      ctaText: 'Kerjasama Payroll',
      ctaType: 'whatsapp'
    }
  ],

  deposito: [
    {
      id: 'deposito-reguler',
      code: 'DEP-01',
      name: 'Deposito Berjangka Bank Majalengka',
      badge: 'Bunga Maksimal LPS',
      category: 'deposito',
      image: 'assets/img/produk/IMG_2928.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Investasi berjangka terpercaya dengan suku bunga kompetitif dijamin penuh LPS.',
      shortDesc: 'Pilihan investasi berjangka yang aman dan memberikan imbal hasil maksimal bagi perorangan maupun korporasi, dengan fleksibilitas jangka waktu penempatan 1, 3, 6, dan 12 bulan.',
      ketentuan: [
        'Pilihan jangka waktu penempatan: 1 Bulan, 3 Bulan, 6 Bulan, dan 12 Bulan.',
        'Suku bunga penjaminan LPS sangat bersaing di atas rata-rata bunga deposito bank umum.',
        'Fasilitas Automatic Roll Over (ARO) untuk perpanjangan pokok otomatis atau pokok + bunga.',
        'Bunga dapat ditransfer otomatis setiap bulan ke rekening tabungan nasabah di bank mana pun.',
        'Dapat dijadikan agunan pinjaman kredit dengan proses cepat jika mendadak butuh likuiditas.',
        'Dijamin 100% oleh Lembaga Penjamin Simpanan (LPS) hingga Rp 2.000.000.000,-.'
      ],
      syarat: [
        'Fotokopi KTP / SIM / Paspor yang masih berlaku (perorangan).',
        'Legalitas pendirian, NIB, dan KTP Pengurus (khusus badan usaha/yayasan).',
        'Memiliki rekening tabungan aktif di BPR Majalengka untuk penampungan bunga.',
        'Penempatan nominal deposito awal minimal Rp 1.000.000,-.'
      ],
      ctaText: 'Simulasi Bunga Deposito',
      ctaType: 'whatsapp'
    },
    {
      id: 'deposito-suka-suka',
      code: 'DEP-02',
      name: 'Deposito Suka-Suka (Hadiah Langsung)',
      badge: 'Hadiah Tanpa Diundi',
      category: 'deposito',
      image: 'assets/img/produk/IMG_2928.jpeg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Simpan dana deposito hari ini, langsung bawa pulang hadiah impian tanpa diundi!',
      shortDesc: 'Program deposito istimewa di mana nasabah langsung menentukan hadiah favoritnya di muka (Sepeda Motor, Smart TV, Lemari Es, Smartphone, hingga Emas Batangan Logam Mulia Antam) begitu dana ditempatkan.',
      ketentuan: [
        'Hadiah langsung diserahkan di muka tanpa proses undian apa pun.',
        'Pilihan tenor penempatan 6, 12, 18, atau 24 bulan sesuai tier hadiah yang dipilih.',
        'Pokok deposito tetap utuh 100% dan dikembalikan penuh saat jatuh tempo.',
        'Pilihan hadiah bergaransi resmi dari distributor terpercaya.',
        'Dana tersimpan aman dan terdaftar pada program penjaminan simpanan LPS.'
      ],
      syarat: [
        'Fotokopi KTP / e-KTP yang masih berlaku.',
        'Menandatangani formulir keikutsertaan program Deposito Hadiah Langsung.',
        'Menempatkan dana baru (fresh fund) sesuai ketentuan paket hadiah.',
        'Komitmen dana mengendap hingga masa jatuh tempo berakhir.'
      ],
      ctaText: 'Katalog Hadiah Deposito',
      ctaType: 'whatsapp'
    }
  ],

  kredit: [
    {
      id: 'kapesta',
      code: 'KRD-01',
      name: 'KAPESTA (Kredit Pegawai Swasta)',
      badge: 'Bunga Ringan',
      category: 'kredit',
      image: 'assets/img/produk/KAPESTA.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Fasilitas pinjaman multiguna cepat untuk karyawan swasta dan pekerja pabrik.',
      shortDesc: 'Pinjaman kebutuhan keluarga atau modal sampingan bagi karyawan tetap maupun kontrak rekanan perusahaan swasta di Kabupaten Majalengka dan wilayah Ciayumajakuning.',
      ketentuan: [
        'Plafon pinjaman mulai Rp 3.000.000,- hingga Rp 50.000.000,-.',
        'Jangka waktu pinjaman (tenor) fleksibel mulai 12 hingga 36 bulan.',
        'Skema angsuran tetap (flat) setiap bulan atau mekanisme potong gaji.',
        'Proses verifikasi dan persetujuan cepat (1 - 3 hari kerja).',
        'Dilindungi oleh asuransi jiwa kredit.'
      ],
      syarat: [
        'Fotokopi KTP pemohon dan suami/istri.',
        'Fotokopi Kartu Keluarga dan Surat Nikah.',
        'Slip gaji asli 3 bulan terakhir atau surat keterangan penghasilan dari bendahara/HRD.',
        'Surat rekomendasi / surat keterangan bekerja dari pimpinan perusahaan.',
        'Agunan fleksibel (BPKB motor/mobil atau SHM/AJB).'
      ],
      ctaText: 'Ajukan KAPESTA Sekarang',
      ctaType: 'form'
    },
    {
      id: 'kan',
      code: 'KRD-02',
      name: 'KAN (Kredit Aparatur Negara)',
      badge: 'Plafon Tinggi',
      category: 'kredit',
      image: 'assets/img/produk/KAN.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Pembiayaan khusus PNS dan Pegawai Pemerintah di Kabupaten Majalengka.',
      shortDesc: 'Solusi pembiayaan konsumtif serbaguna bagi ASN, pejabat fungsional daerah, dan PPPK dengan plafon tinggi dan suku bunga preferensial paling ringan.',
      ketentuan: [
        'Plafon pinjaman hingga Rp 250.000.000,- sesuai kemampuan angsuran gaji.',
        'Tenor sangat panjang hingga 10 s/d 15 tahun (menyesuaikan batas usia pensiun).',
        'Suku bunga khusus ASN dengan proses persetujuan express 1 hari kerja cair.',
        'Pembayaran angsuran terintegrasi potong gaji langsung dari bendahara dinas.',
        'Perlindungan asuransi jiwa kredit penuh.'
      ],
      syarat: [
        'Fotokopi KTP pemohon dan pasangan.',
        'Fotokopi Kartu Keluarga.',
        'SK Pengangkatan CPNS & SK PNS/PPPK terakhir (asli disimpan sebagai agunan utama).',
        'Kartu Pegawai (Karpeg) & Taspen.',
        'Daftar rincian gaji terakhir yang ditandatangani bendahara pengeluaran.'
      ],
      ctaText: 'Ajukan KAN Sekarang',
      ctaType: 'form'
    },
    {
      id: 'kredit-konstruksi',
      code: 'KRD-03',
      name: 'Kredit Pembiayaan Konstruksi & Proyek',
      badge: 'Rekanan Pengadaan',
      category: 'kredit',
      image: 'assets/img/produk/multiguna.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Dukungan modal kerja kontraktor pengerjaan proyek infrastruktur daerah.',
      shortDesc: 'Fasilitas pinjaman modal kerja bagi kontraktor, pengembang rekanan APBD Majalengka / APBN untuk kelancaran pembelian material dan upah tenaga kerja proyek.',
      ketentuan: [
        'Plafon pembiayaan hingga 70% dari nilai Surat Perintah Kerja (SPK) / Kontrak.',
        'Pola pengembalian menyesuaikan termin pencairan termin fisik proyek (turnkey).',
        'Pilihan agunan tambahan tanah/bangunan atau jaminan piutang proyek.',
        'Pendampingan analisa teknis lapangan oleh analis perbankan berpengalaman.'
      ],
      syarat: [
        'Legalitas badan usaha (Akta Pendirian PT/CV, NIB, SIUJK, NPWP Perusahaan).',
        'Salinan SPK / Kontrak Kerja Asli yang masih berlaku dari instansi pemberi kerja.',
        'Rekening koran perusahaan 6 bulan terakhir.',
        'Dokumen agunan tambahan berupa SHM/SHGB.'
      ],
      ctaText: 'Konsultasi Kredit Proyek',
      ctaType: 'form'
    },
    {
      id: 'kredit-pensiunan',
      code: 'KRD-04',
      name: 'Kredit Pensiunan Sejahtera',
      badge: 'Masa Purna Tenang',
      category: 'kredit',
      image: 'assets/img/produk/pensiunan.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Bakti penghormatan bagi purnabakti untuk membuka usaha dan kebutuhan keluarga.',
      shortDesc: 'Fasilitas pinjaman bagi para pensiunan PNS, TNI, POLRI, dan BUMN untuk memenuhi renovasi hunian, hajatan anak, maupun modal usaha produktif di masa tua.',
      ketentuan: [
        'Plafon pinjaman hingga Rp 100.000.000,-.',
        'Batas usia saat kredit lunas mencapai 75 tahun.',
        'Suku bunga ringan dan angsuran terpotong otomatis dari uang pensiun bulanan.',
        'Wajib dilindungi asuransi jiwa purnabakti sehingga tidak membebani ahli waris.'
      ],
      syarat: [
        'Fotokopi KTP pemohon dan pasangan.',
        'SK Pensiun asli (Karip / SKEP).',
        'Buku tabungan gaji pensiun Taspen / Asabri.',
        'Surat Keterangan Kematian pasangan (apabila pensiun janda/duda).'
      ],
      ctaText: 'Ajukan Kredit Pensiunan',
      ctaType: 'form'
    },
    {
      id: 'kredit-modal-kerja',
      code: 'KRD-05',
      name: 'Kredit Modal Kerja (KMK)',
      badge: 'Solusi Arus Kas',
      category: 'kredit',
      image: 'assets/img/produk/multiguna.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Perkuat persediaan barang dagang dan percepat perputaran omzet usaha Anda.',
      shortDesc: 'Pinjaman modal usaha untuk pedagang toko grosir, distributor sembako, pemilik bengkel, dan industri olahan di seluruh penjuru Majalengka.',
      ketentuan: [
        'Plafon pinjaman mulai Rp 10.000.000,- s/d Rp 500.000.000,-.',
        'Tenor pinjaman mulai 12 bulan hingga 60 bulan (5 tahun).',
        'Pilihan skema angsuran pokok dan bunga flat atau bunga menurun (efektif).',
        'Agunan sertifikat tanah (SHM/SHGB) atau BPKB kendaraan niaga.'
      ],
      syarat: [
        'Fotokopi KTP suami/istri dan Kartu Keluarga.',
        'Surat Keterangan Usaha (SKU) dari Kantor Desa/Kelurahan atau NIB.',
        'Usaha telah berjalan aktif minimal 1 tahun.',
        'Dokumen bukti kepemilikan agunan asli.'
      ],
      ctaText: 'Ajukan Modal Kerja',
      ctaType: 'form'
    },
    {
      id: 'kredit-pertanian',
      code: 'KRD-06',
      name: 'Kredit Pertanian & Musiman',
      badge: 'Bayar Pasca Panen',
      category: 'kredit',
      image: 'assets/img/produk/KAN.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Mitra setia petani Majalengka: modal tanam mudah, bayar saat panen raya.',
      shortDesc: 'Pembiayaan khusus petani padi, budidaya bawang merah, cabai, dan palawija dengan skema pembayaran fleksibel Yarnen (Bayar Setelah Panen) tanpa beban angsuran bulanan.',
      ketentuan: [
        'Pola pelunasan berjangka 3, 4, atau 6 bulan sesuai masa panen komoditas.',
        'Plafon pinjaman dihitung berdasarkan estimasi luas lahan tanam dan kebutuhan bibit/pupuk.',
        'Suku bunga terjangkau untuk menunjang ketahanan pangan daerah Majalengka.'
      ],
      syarat: [
        'Fotokopi KTP dan Kartu Keluarga petani pemohon.',
        'Surat keterangan penggarap / kepemilikan lahan sawah/kebun.',
        'Rekomendasi dari Ketua Kelompok Tani (Poktan) setempat.',
        'Agunan sertifikat tanah darat/sawah atau BPKB.'
      ],
      ctaText: 'Ajukan Kredit Pertanian',
      ctaType: 'form'
    },
    {
      id: 'kredit-talangan',
      code: 'KRD-07',
      name: 'Kredit Talangan (Bridging Fund)',
      badge: 'Pencairan Kilat',
      category: 'kredit',
      image: 'assets/img/produk/multiguna.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Solusi dana tunai cepat untuk kebutuhan mendesak dan bridging pembayaran bisnis.',
      shortDesc: 'Pinjaman jangka pendek berkecepatan tinggi bagi nasabah yang membutuhkan dana talangan segera sebelum dana pelunasan utama masuk.',
      ketentuan: [
        'Jangka waktu penempatan singkat 1 s/d 6 bulan.',
        'Proses analisa dan persetujuan kilat dalam 24 jam kerja.',
        'Pelunasan sewaktu-waktu tanpa penalti berlebih apabila dana pelunasan telah tersedia.'
      ],
      syarat: [
        'Fotokopi KTP dan Kartu Keluarga.',
        'Bukti sumber pengembalian pasti (invoice, SPK, sertifikat deposito, dll).',
        'Dokumen jaminan likuid atau aset tanah/kendaraan.'
      ],
      ctaText: 'Konsultasi Dana Talangan',
      ctaType: 'form'
    },
    {
      id: 'kredit-kios',
      code: 'KRD-08',
      name: 'Kredit Pemilikan Kios & Los Pasar',
      badge: 'Pedagang Pasar',
      category: 'kredit',
      image: 'assets/img/warung-sembako.jpg',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Miliki kios dan tempat dasaran usaha mandiri di pasar-pasar Kabupaten Majalengka.',
      shortDesc: 'Pembiayaan pembelian hak guna pakai, renovasi, atau sewa jangka panjang kios dan los di pasar Kadipaten, Jatiwangi, Majalengka Kota, Talaga, dan Cikijing.',
      ketentuan: [
        'Plafon hingga 80% dari harga kios/los pasar.',
        'Tenor pinjaman panjang hingga 5 tahun agar angsuran harian/bulanan ringan bagi pedagang.',
        'Petugas pickup service siap menjemput angsuran langsung di lapak pedagang setiap hari.'
      ],
      syarat: [
        'KTP pemohon dan Kartu Keluarga.',
        'Surat Izin Pemakaian Tempat Dasaran (SIPTD) / Bukti kepemilikan kios dari dinas pengelola pasar.',
        'Usaha perdagangan di pasar telah aktif minimal 6 bulan.'
      ],
      ctaText: 'Ajukan Kredit Kios',
      ctaType: 'form'
    },
    {
      id: 'kredit-perak',
      code: 'KRD-09',
      name: 'Kredit Raharja (PERAK - Peduli Usaha Mikro)',
      badge: 'Subsidi Bunga',
      category: 'kredit',
      image: 'assets/img/produk/perak.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Program BUMD Majalengka memberantas rentenir dan pinjaman online ilegal.',
      shortDesc: 'Kredit mikro berbunga sangat rendah yang disubsidi untuk membantu pedagang keliling, pengrajin anyaman bambu, penjahit, dan pelaku usaha ultra mikro rumahan.',
      ketentuan: [
        'Plafon pinjaman mulai Rp 1.000.000,- s/d Rp 10.000.000,-.',
        'Bunga ultra-ringan tanpa potongan tersembunyi.',
        'Syarat administrasi sangat mudah dan ramah pelaku usaha kecil.',
        'Tenor 6 hingga 24 bulan.'
      ],
      syarat: [
        'KTP warga domisili Kabupaten Majalengka.',
        'Kartu Keluarga.',
        'Foto usaha aktif di rumah / tempat jualan.',
        'Surat keterangan domisili usaha dari RT/RW setempat.'
      ],
      ctaText: 'Ajukan Kredit PERAK',
      ctaType: 'form'
    },
    {
      id: 'kredit-ksg',
      code: 'KRD-10',
      name: 'KSG (Kredit Sertifikasi Guru)',
      badge: 'Khusus Guru',
      category: 'kredit',
      image: 'assets/img/produk/KSG.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Kredit kesejahteraan guru bersertifikasi pendidik di seluruh Majalengka.',
      shortDesc: 'Fasilitas pinjaman perorangan bagi para tenaga pendidik (Guru ASN & Swasta) penerima Tunjangan Profesi Guru (TPG) untuk kebutuhan keluarga terencana.',
      ketentuan: [
        'Plafon pinjaman hingga Rp 100.000.000,-.',
        'Pola angsuran dapat disesuaikan dengan jadwal pencairan tunjangan sertifikasi triwulan atau bulanan.',
        'Bunga bersaing dengan proses persetujuan cepat.'
      ],
      syarat: [
        'Fotokopi KTP pemohon dan pasangan.',
        'Fotokopi Sertifikat Pendidik (Sertifikasi Guru).',
        'Rekening koran / buku tabungan penerima tunjangan profesi guru 6 bulan terakhir.',
        'Surat rekomendasi dari Kepala Sekolah.'
      ],
      ctaText: 'Ajukan KSG Guru',
      ctaType: 'form'
    },
    {
      id: 'kredit-non-asn',
      code: 'KRD-11',
      name: 'Kredit Non-ASN & Pegawai PPPK',
      badge: 'Pegawai Daerah',
      category: 'kredit',
      image: 'assets/img/produk/non asn.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Pinjaman resmi terpercaya bagi honorer, tenaga kontrak, dan PPPK daerah.',
      shortDesc: 'Pembiayaan multiguna bagi Pegawai Pemerintah dengan Perjanjian Kerja (PPPK) dan tenaga honorer di OPD, Puskesmas, dan sekolah negeri di lingkungan Pemkab Majalengka.',
      ketentuan: [
        'Plafon pinjaman proporsional disesuaikan dengan sisa masa kontrak kerja PPPK.',
        'Angsuran tetap bulanan dipotong melalui koordinasi bendahara dinas.',
        'Dilindungi asuransi jiwa kredit.'
      ],
      syarat: [
        'Fotokopi KTP pemohon dan pasangan serta Kartu Keluarga.',
        'Surat Keputusan (SK) Pengangkatan PPPK / Honorer asli yang masih berlaku.',
        'Slip gaji terakhir yang ditandatangani bendahara.',
        'Surat rekomendasi pimpinan instansi / dinas.'
      ],
      ctaText: 'Ajukan Kredit PPPK',
      ctaType: 'form'
    },
    {
      id: 'kredit-multiguna',
      code: 'KRD-12',
      name: 'Kredit Multiguna Keluarga',
      badge: 'Kebutuhan Bebas',
      category: 'kredit',
      image: 'assets/img/produk/multiguna.png',
      heroImage: 'assets/img/hero-batik.jpg',
      slogan: 'Satu solusi keuangan terpercaya untuk aneka rencana penting keluarga Anda.',
      shortDesc: 'Pinjaman multiguna beragunan untuk membiayai renovasi rumah impian, dana pendidikan perguruan tinggi anak, biaya pernikahan, hingga fasilitas kesehatan darurat.',
      ketentuan: [
        'Plafon fleksibel mulai Rp 10.000.000,- hingga Rp 300.000.000,-.',
        'Jangka waktu pinjaman hingga 5 tahun (60 bulan).',
        'Agunan berupa sertifikat tanah (SHM/SHGB) atau BPKB kendaraan roda empat / roda dua.',
        'Proses taksasi nilai agunan transparan dan profesional.'
      ],
      syarat: [
        'Fotokopi KTP suami dan istri.',
        'Fotokopi Kartu Keluarga dan Surat Nikah.',
        'Bukti penghasilan tetap atau slip gaji / catatan usaha.',
        'Sertifikat tanah asli atau BPKB kendaraan beserta STNK atas nama pribadi/keluarga.'
      ],
      ctaText: 'Ajukan Kredit Multiguna',
      ctaType: 'form'
    }
  ]
};

/* ==========================================================================
   2. DATABASE KANTOR CABANG & LOKASI
   ========================================================================== */
const BRANCHES_DATA = [
  {
    name: 'Kantor Pusat Operasional',
    type: 'Pusat',
    address: 'Jl. Raya K.H. Abdul Halim No. 338, Majalengka Wetan, Kec. Majalengka, Jawa Barat 45411',
    phone: '(0233) 281144',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB',
    isMain: true
  },
  {
    name: 'Kantor Cabang Kadipaten',
    type: 'Cabang',
    address: 'Jl. Raya Kadipaten No. 45, Kec. Kadipaten (Dekat Pasar Kadipaten)',
    latitude: '-6.7632246516128065',
    longitude: '108.1682402947551',
    phone: '(0233) 282510',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Jatitujuh',
    type: 'Cabang',
    address: 'Jl. Raya Utara No.113 Jatitujuh',
    latitude: '-6.6439472368882635',
    longitude: '108.2294895625247',
    phone: '(0233) 8888211',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Cikijing',
    type: 'Cabang',
    address: 'Jl. Raya Kasturi No. 15, Kec. Cikijing (Pusat Konveksi Celana Jeans)',
    latitude: '-7.016916098244055',
    longitude: '108.36454874491558',
    phone: '(0233) 891340',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Rajagaluh',
    type: 'Cabang',
    address: 'Jl. Pangeran Muhamad No. 34, Kec. Rajagaluh (Sentra Anyaman Bambu)',
    latitude: '-6.779398593568954',
    longitude: '108.3447027455341',
    phone: '(0233) 511450',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Bantarujeg',
    type: 'Cabang',
    address: 'Jl. Siliwangi No.91 Bantarujeg',
    latitude: '-6.968736619525069',
    longitude: '108.23936331773582',
    phone: '(0233) 8316346',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Sukahaji',
    type: 'Cabang',
    address: 'Jl. Raya Sukahaji No. 10, Cikalong, Kec. Sukahaji',
    latitude: '-6.8190775141653255',
    longitude: '108.2807762434407',
    phone: '(0233) 882190',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Kertajati',
    type: 'Cabang',
    address: 'Jl. Kertajati-Kadipaten Km 3, Kec. Kertajati (Kawasan Bandara Internasional Kertajati)',
    latitude: '-6.677310235565713',
    longitude: '108.1890547352578',
    phone: '(0233) 883100',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
  {
    name: 'Kantor Cabang Ligung',
    type: 'Cabang',
    address: 'Jl. Raya Ligung No. 78, Kec. Ligung (Sentra Industri Pabrik)',
    latitude: '-6.652526614832701',
    longitude: '108.28211492563509',
    phone: '(0233) 884520',
    whatsapp: '0811-1111-6526',
    hours: 'Senin - Jumat: 08:00 - 15:30 WIB'
  },
];

/* ==========================================================================
   3. DATABASE ARTIKEL & LITERASI KEUANGAN
   ========================================================================== */
const ARTICLES_DATA = [
  {
    id: 1,
    tag: 'Perencanaan Finansial',
    tagColor: 'blue',
    title: 'Mulai Dana Darurat dari Kebiasaan Sederhana Sehari-hari',
    image: 'assets/img/perencanaan-keluarga.jpg',
    excerpt: 'Langkah awal yang realistis untuk memisahkan dana kebutuhan pokok dan cadangan darurat keluarga demi ketenangan hidup masa depan.',
    date: '24 Oktober 2026',
    readTime: '4 menit baca',
    content: `
      <p class="mb-4">Banyak keluarga di Kabupaten Majalengka merasa bahwa membentuk dana darurat membutuhkan penghasilan dalam jumlah besar. Padahal, kunci utama pembentukan dana darurat bukanlah besarnya nominal sekaligus, melainkan konsistensi memisahkan porsi kecil di awal setiap kali menerima pemasukan.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">1. Pisahkan Rekening Kebutuhan dan Rekening Cadangan</h4>
      <p class="mb-4">Mencampurkan dana belanja pasar harian dengan simpanan adalah pemicu utama dana darurat sering terpakai tanpa sadar. Dengan membuka rekening tabungan khusus seperti <strong>SIDASI (Simpanan Dana Siaga)</strong> di Bank Majalengka yang bebas potongan administrasi bulanan memberatkan, uang cadangan Anda tetap utuh dan bertumbuh dengan bunga harian.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">2. Mulai dari Aturan 10%</h4>
      <p class="mb-4">Cukup sisihkan 10% dari penghasilan tetap atau keuntungan dagang Anda setiap minggu. Jika penghasilan mingguan Anda Rp 1.000.000,-, sisihkan Rp 100.000,- langsung ke rekening simpanan. Petugas Bank Majalengka bahkan menyediakan fasilitas <em>Pickup Service</em> jemput setoran langsung ke lokasi Anda sehingga menabung tidak merepotkan waktu bekerja.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">3. Dana Terjamin Aman di BPR</h4>
      <p class="mb-4">Simpanan Anda di Perumda BPR Majalengka dijamin 100% oleh <strong>Lembaga Penjamin Simpanan (LPS)</strong> hingga Rp 2.000.000.000,- per nasabah. Ketenangan pikiran keluarga Anda adalah prioritas kami.</p>
    `
  },
  {
    id: 2,
    tag: 'Panduan UMKM',
    tagColor: 'amber',
    title: 'Pisahkan Uang Usaha Warung dan Uang Dapur Pribadi',
    image: 'assets/img/warung-sembako.jpg',
    excerpt: 'Pencatatan kas harian yang tertib menghindarkan pedagang kecil dari modal yang tergerus kebutuhan konsumtif.',
    date: '18 Oktober 2026',
    readTime: '5 menit baca',
    content: `
      <p class="mb-4">Bagi para pemilik toko kelontong, pedagang pasar Kadipaten, dan warung makan di pelosok Majalengka, salah satu tantangan terbesar adalah menjaga modal usaha tidak tergerus kebutuhan dapur rumah tangga sendiri.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">1. Gaji Diri Sendiri Secara Tetap</h4>
      <p class="mb-4">Tentukan nominal "gaji" mingguan atau bulanan yang wajar untuk kebutuhan rumah tangga Anda. Ambil hanya sejumlah tersebut dari keuntungan bersih toko, dan jangan mengambil uang kembalian di laci kasir secara acak untuk keperluan pribadi.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">2. Miliki Buku Kas Catatan Harian Sederhana</h4>
      <p class="mb-4">Cukup sediakan buku tulis bertanggal dengan tiga kolom: Uang Masuk, Uang Keluar (Kulakan), dan Sisa Saldo Kas. Setiap malam sebelum menutup toko, luangkan 5 menit untuk mencocokkan uang fisik dengan catatan buku.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">3. Dukungan Modal Usaha BPR Majalengka</h4>
      <p class="mb-4">Bila usaha warung Anda membutuhkan suntikan permodalan untuk memperbanyak stok dagangan grosir menjelang masa panen raya atau hari raya, Bank Majalengka menyediakan fasilitas <strong>Kredit Modal Kerja (KMK)</strong> dan program <strong>Kredit PERAK</strong> dengan angsuran ringan dan persyaratan yang sangat bersahabat.</p>
    `
  },
  {
    id: 3,
    tag: '#AwasModus',
    tagColor: 'red',
    title: 'Kenali Pesan Mencurigakan, Jaga Kerahasiaan Data Perbankan',
    image: 'assets/img/pensiunan-hp.jpg',
    excerpt: 'Petugas Bank Majalengka tidak pernah meminta kode OTP, PIN, password, atau biaya transfer ke rekening pribadi pegawai.',
    date: '10 Oktober 2026',
    readTime: '3 menit baca',
    content: `
      <p class="mb-4">Seiring berkembangnya transaksi digital, modus penipuan berkedok undian berhadiah, undangan pernikahan digital (file APK), dan pesan WhatsApp palsu yang mengatasnamakan bank kian marak mengincar masyarakat.</p>
      <h4 class="font-bold text-slate-800 text-lg mb-2">Prinsip Aman Transaksi Bank Majalengka:</h4>
      <ul class="list-disc pl-5 mb-4 space-y-2">
        <li><strong>JANGAN PERNAH</strong> memberitahukan nomor PIN, password, atau kode OTP kepada siapa pun, termasuk oknum yang mengaku sebagai pegawai bank.</li>
        <li><strong>JANGAN TRANSFER</strong> dana biaya administrasi pinjaman atau undian ke rekening bank atas nama perorangan atau nomor rekening pribadi petugas. Seluruh transaksi resmi disetorkan langsung di loket kantor kas atau rekening resmi Perumda BPR Majalengka.</li>
        <li><strong>JANGAN KLIK</strong> tautan file unduhan dengan ekstensi <code>.APK</code> yang dikirimkan melalui nomor WhatsApp asing.</li>
      </ul>
      <p class="mb-4">Bila Anda mendapati aktivitas mencurigakan atau dihubungi nomor tidak dikenal, segera konfirmasi ke Call Center resmi Bank Majalengka di <strong>(0233) 281144</strong> atau WhatsApp resmi <strong>0811-1111-6526</strong>.</p>
    `
  }
];

/* ==========================================================================
   4. NAVIGATION & MOBILE DRAWER LOGIC
   ========================================================================== */
function initNavbar() {
  const header = document.getElementById('main-header');
  const mobileToggle = document.getElementById('mobile-menu-toggle');
  const mobileDrawer = document.getElementById('mobile-drawer');
  const mobileDrawerClose = document.getElementById('mobile-drawer-close');
  const mobileBackdrop = document.getElementById('mobile-drawer-backdrop');

  // Scroll effect
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      header.classList.add('glass-header-scrolled');
    } else {
      header.classList.remove('glass-header-scrolled');
    }
  });

  // Mobile drawer controls
  const openDrawer = () => {
    mobileDrawer.classList.remove('translate-x-full');
    mobileBackdrop.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
  };

  const closeDrawer = () => {
    mobileDrawer.classList.add('translate-x-full');
    mobileBackdrop.classList.add('hidden');
    document.body.classList.remove('overflow-hidden');
  };

  if (mobileToggle) mobileToggle.addEventListener('click', openDrawer);
  if (mobileDrawerClose) mobileDrawerClose.addEventListener('click', closeDrawer);
  if (mobileBackdrop) mobileBackdrop.addEventListener('click', closeDrawer);

  // Close drawer on clicking links
  document.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', closeDrawer);
  });
}

/* ==========================================================================
   5. INTERACTIVE FINANCIAL LOAN CALCULATOR ENGINE
   (Sesuai Sketsa Halaman 10 & Figma Section 6)
   ========================================================================== */
function initSimulator() {
  const plafondRange = document.getElementById('sim-plafond-range');
  const plafondInput = document.getElementById('sim-plafond-input');
  const tenorButtons = document.querySelectorAll('.sim-tenor-btn');
  const rateSchemeSelect = document.getElementById('sim-rate-scheme');
  const presetButtons = document.querySelectorAll('.sim-preset-btn');

  // Display fields
  const displayMonthlyInstallment = document.getElementById('sim-result-monthly');
  const displayPrincipalMonthly = document.getElementById('sim-result-principal');
  const displayInterestMonthly = document.getElementById('sim-result-interest');
  const displayTotalLoan = document.getElementById('sim-result-total');
  const displayPlafondSummary = document.getElementById('sim-result-plafond');
  const displayTenorSummary = document.getElementById('sim-result-tenor');
  const displayTotalInterest = document.getElementById('sim-result-total-interest');
  const btnKonsultasiWa = document.getElementById('sim-btn-wa');
  const btnAjukanKredit = document.getElementById('sim-btn-ajukan');

  if (!plafondRange || !plafondInput) return;

  let currentPlafond = 25000000;
  let currentTenor = 24; // bulan
  let currentScheme = 'flat'; // flat vs effective
  const flatAnnualRate = 0.06; // 6% per tahun sesuai Figma & Sketsa Halaman 10 (Rp 1.166.667 / bln)
  const effectiveAnnualRate = 0.105; // ~10.5% per tahun suku bunga efektif

  // Format Helper
  const formatRupiah = (num) => {
    return 'Rp ' + Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  };

  const calculateLoan = () => {
    let monthlyInstallment = 0;
    let principalMonthly = 0;
    let interestMonthly = 0;
    let totalRepayment = 0;

    if (currentScheme === 'flat') {
      principalMonthly = currentPlafond / currentTenor;
      interestMonthly = (currentPlafond * flatAnnualRate) / 12;
      monthlyInstallment = principalMonthly + interestMonthly;
      totalRepayment = monthlyInstallment * currentTenor;
    } else {
      // Anuitas / Efektif
      const monthlyRate = effectiveAnnualRate / 12;
      monthlyInstallment = (currentPlafond * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -currentTenor));
      totalRepayment = monthlyInstallment * currentTenor;
      interestMonthly = (totalRepayment - currentPlafond) / currentTenor;
      principalMonthly = monthlyInstallment - interestMonthly;
    }

    // Update UI elements
    if (displayMonthlyInstallment) displayMonthlyInstallment.textContent = formatRupiah(monthlyInstallment);
    if (displayPrincipalMonthly) displayPrincipalMonthly.textContent = formatRupiah(principalMonthly);
    if (displayInterestMonthly) displayInterestMonthly.textContent = formatRupiah(interestMonthly);
    if (displayTotalInterest) displayTotalInterest.textContent = formatRupiah(totalRepayment - currentPlafond);
    if (displayTotalLoan) displayTotalLoan.textContent = formatRupiah(totalRepayment);
    if (displayPlafondSummary) displayPlafondSummary.textContent = formatRupiah(currentPlafond);
    if (displayTenorSummary) displayTenorSummary.textContent = `${currentTenor} Bulan`;

    // Update WhatsApp Consultation Link
    if (btnKonsultasiWa) {
      const waText = encodeURIComponent(
        `Halo Perumda BPR Majalengka, saya ingin konsultasi simulasi kredit:\n\n` +
        `• Plafon Pinjaman: ${formatRupiah(currentPlafond)}\n` +
        `• Jangka Waktu: ${currentTenor} Bulan\n` +
        `• Skema Bunga: ${currentScheme === 'flat' ? 'Bunga Flat Tetap (6% p.a)' : 'Bunga Efektif'}\n` +
        `• Estimasi Angsuran: ${formatRupiah(monthlyInstallment)} / bulan\n` +
        `• Total Pengembalian: ${formatRupiah(totalRepayment)}\n\n` +
        `Mohon informasi persyaratan dan prosedur pengajuannya. Terima kasih.`
      );
      btnKonsultasiWa.href = `https://wa.me/6281111116526?text=${waText}`;
    }
  };

  // Sync inputs
  plafondRange.addEventListener('input', (e) => {
    currentPlafond = parseInt(e.target.value, 10);
    plafondInput.value = formatRupiah(currentPlafond);
    calculateLoan();
  });

  plafondInput.addEventListener('change', (e) => {
    const rawVal = parseInt(e.target.value.replace(/[^0-9]/g, ''), 10) || 5000000;
    currentPlafond = Math.min(Math.max(rawVal, 1000000), 100000000);
    plafondRange.value = currentPlafond;
    plafondInput.value = formatRupiah(currentPlafond);
    calculateLoan();
  });

  // Preset Buttons
  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      presetButtons.forEach(b => b.classList.remove('bg-bpr-blue', 'text-white'));
      btn.classList.add('bg-bpr-blue', 'text-white');
      currentPlafond = parseInt(btn.dataset.amount, 10);
      plafondRange.value = currentPlafond;
      plafondInput.value = formatRupiah(currentPlafond);
      calculateLoan();
    });
  });

  // Tenor Buttons
  tenorButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tenorButtons.forEach(b => {
        b.classList.remove('bg-bpr-navy', 'text-white', 'shadow-sm');
        b.classList.add('bg-slate-100', 'text-slate-700');
      });
      btn.classList.remove('bg-slate-100', 'text-slate-700');
      btn.classList.add('bg-bpr-navy', 'text-white', 'shadow-sm');
      currentTenor = parseInt(btn.dataset.tenor, 10);
      calculateLoan();
    });
  });

  // Rate Scheme Select
  if (rateSchemeSelect) {
    rateSchemeSelect.addEventListener('change', (e) => {
      currentScheme = e.target.value;
      calculateLoan();
    });
  }

  // Ajukan Pinjaman Button -> Opens Form Modal with pre-filled numbers
  if (btnAjukanKredit) {
    btnAjukanKredit.addEventListener('click', () => {
      openFormPengajuan(currentPlafond, currentTenor);
    });
  }

  // Initial Calculation
  calculateLoan();
}

/* ==========================================================================
   6. FORM PENGAJUAN KREDIT INTERAKTIF
   (Sesuai Sketsa Halaman 9 & Ketentuan Perbankan)
   ========================================================================== */
function initFormPengajuan() {
  const modal = document.getElementById('modal-pengajuan-kredit');
  const closeBtn = document.getElementById('modal-pengajuan-close');
  const cancelBtn = document.getElementById('modal-pengajuan-cancel');
  const form = document.getElementById('form-pengajuan-kredit');
  const captchaQuestion = document.getElementById('captcha-question');
  const captchaRefresh = document.getElementById('captcha-refresh');
  const captchaAnswerInput = document.getElementById('form-captcha-answer');

  if (!modal || !form) return;

  let currentCaptchaResult = 0;

  const generateCaptcha = () => {
    const num1 = Math.floor(Math.random() * 8) + 2; // 2 - 9
    const num2 = Math.floor(Math.random() * 8) + 1; // 1 - 8
    currentCaptchaResult = num1 + num2;
    if (captchaQuestion) {
      captchaQuestion.textContent = `${num1} + ${num2} = ?`;
    }
    if (captchaAnswerInput) captchaAnswerInput.value = '';
  };

  generateCaptcha();
  if (captchaRefresh) captchaRefresh.addEventListener('click', generateCaptcha);

  // Close handlers
  const closeModal = () => {
    modal.classList.remove('active');
    document.body.classList.remove('overflow-hidden');
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Submit Handler
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Validasi NIK (16 digit)
    const nikInput = document.getElementById('form-nik');
    const nikVal = nikInput.value.trim();
    if (!/^\d{16}$/.test(nikVal)) {
      alert('Nomor Induk Kependudukan (NIK) harus terdiri dari 16 digit angka.');
      nikInput.focus();
      return;
    }

    // Validasi Captcha
    const userCaptcha = parseInt(captchaAnswerInput.value.trim(), 10);
    if (userCaptcha !== currentCaptchaResult) {
      alert('Hasil perhitungan CAPTCHA salah. Silakan coba lagi.');
      generateCaptcha();
      captchaAnswerInput.focus();
      return;
    }

    // Ambil data form
    const formData = {
      nik: nikVal,
      nama: document.getElementById('form-nama').value.trim(),
      alamat: document.getElementById('form-alamat').value.trim(),
      hp: document.getElementById('form-hp').value.trim(),
      email: document.getElementById('form-email').value.trim(),
      afiliasi: document.getElementById('form-afiliasi').value.trim() || '-',
      nominal: document.getElementById('form-nominal').value.trim(),
      tenor: document.getElementById('form-tenor').value.trim(),
      tujuan: document.getElementById('form-tujuan').value.trim(),
      sumber: document.getElementById('form-sumber').value.trim(),
      pendapatanTetap: document.getElementById('form-pendapatan-tetap').value.trim(),
      pendapatanLain: document.getElementById('form-pendapatan-lain').value.trim() || '-',
      deskripsiLain: document.getElementById('form-deskripsi-lain').value.trim() || '-',
      agunan: document.getElementById('form-agunan').value.trim()
    };

    // AJAX submit to Laravel Backend
    fetch('/api/pengajuan-kredit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
      },
      body: JSON.stringify(formData)
    })
    .then(async res => {
      const data = await res.json().catch(() => ({}));
      return { ok: res.ok, status: res.status, data };
    })
    .then(({ ok, data }) => {
      if (!ok || !data.success) {
        alert(data.message || 'Gagal mengirim pengajuan kredit. Mohon periksa kembali formulir Anda.');
        modal.classList.add('active');
        document.body.classList.add('overflow-hidden');
        return;
      }
      closeModal();
      const serverRefCode = data?.data?.reference_code;
      showPengajuanSuccessModal(formData, serverRefCode, {
        applicant: data?.data?.applicant_email_notified,
        bank: data?.data?.bank_email_notified
      });
      form.reset();
      generateCaptcha();
    })
    .catch(() => {
      alert('Tidak dapat terhubung ke server. Pengajuan belum dapat dikonfirmasi; silakan coba kembali.');
    });
  });
}

// Global opener for Form Pengajuan
function openFormPengajuan(defaultPlafond, defaultTenor, defaultProduct) {
  const modal = document.getElementById('modal-pengajuan-kredit');
  if (!modal) return;

  if (defaultPlafond) {
    const nominalField = document.getElementById('form-nominal');
    if (nominalField) nominalField.value = defaultPlafond;
  }
  if (defaultTenor) {
    const tenorField = document.getElementById('form-tenor');
    if (tenorField) tenorField.value = defaultTenor;
  }
  if (defaultProduct) {
    const tujuanField = document.getElementById('form-tujuan');
    if (tujuanField) tujuanField.value = `Pengajuan Produk: ${defaultProduct}`;
  }

  modal.classList.add('active');
  document.body.classList.add('overflow-hidden');
}

// Success Modal Handler
function showPengajuanSuccessModal(data, serverRefCode, emailStatus = {}) {
  const successModal = document.getElementById('modal-pengajuan-success');
  if (!successModal) return;

  const refCode = serverRefCode;
  if (!refCode) return;
  
  const refCodeEl = document.getElementById('success-ref-code');
  const detailsEl = document.getElementById('success-details-summary');
  const waBtnEl = document.getElementById('success-btn-wa-confirm');
  const emailNoticeEl = document.getElementById('success-email-notice');

  if (refCodeEl) refCodeEl.textContent = refCode;
  if (emailNoticeEl) {
    const applicantNotice = emailStatus.applicant
      ? `Tanda terima dikirim ke ${data.email}.`
      : `Tanda terima belum berhasil dikirim ke ${data.email}; silakan simpan nomor referensi ini.`;
    const bankNotice = emailStatus.bank
      ? ' Bank juga telah menerima notifikasi.'
      : ' Notifikasi bank belum berhasil dikirim.';
    emailNoticeEl.textContent = applicantNotice + bankNotice;
    emailNoticeEl.className = `text-xs ${emailStatus.applicant && emailStatus.bank ? 'text-emerald-700' : 'text-amber-700'}`;
  }
  if (detailsEl) {
    detailsEl.innerHTML = `
      <div class="grid grid-cols-2 gap-2.5 text-sm text-left p-4 rounded-2xl bg-slate-50">
        <span class="text-slate-500">Nama Pemohon:</span>
        <span class="font-semibold text-slate-800">${data.nama}</span>
        <span class="text-slate-500">NIK KTP:</span>
        <span class="font-semibold text-slate-800">${data.nik}</span>
        <span class="text-slate-500">Besar Pengajuan:</span>
        <span class="font-bold text-bpr-navy">Rp ${parseInt(data.nominal, 10).toLocaleString('id-ID')}</span>
        <span class="text-slate-500">Jangka Waktu:</span>
        <span class="font-semibold text-slate-800">${data.tenor} Bulan</span>
        <span class="text-slate-500">Agunan:</span>
        <span class="font-semibold text-slate-800">${data.agunan}</span>
      </div>
    `;
  }

  if (waBtnEl) {
    const waText = encodeURIComponent(
      `Halo Customer Service BPR Majalengka, saya telah mengisi formulir permohonan kredit online:\n\n` +
      `• No. Registrasi: ${refCode}\n` +
      `• Nama: ${data.nama}\n` +
      `• NIK: ${data.nik}\n` +
      `• Nomor HP: ${data.hp}\n` +
      `• Plafon Diajukan: Rp ${parseInt(data.nominal, 10).toLocaleString('id-ID')}\n` +
      `• Tenor: ${data.tenor} Bulan\n` +
      `• Agunan: ${data.agunan}\n\n` +
      `Mohon dibantu konfirmasi tindak lanjut verifikasi berkas saya. Terima kasih.`
    );
    waBtnEl.href = `https://wa.me/6281111116526?text=${waText}`;
  }

  successModal.classList.add('active');
  document.body.classList.add('overflow-hidden');

  const closeSuccess = document.getElementById('modal-success-close');
  if (closeSuccess) {
    closeSuccess.onclick = () => {
      successModal.classList.remove('active');
      document.body.classList.remove('overflow-hidden');
    };
  }
}

/* ==========================================================================
   2B. HERO PRODUCT CAROUSEL (MENAMPILKAN SEMUA PRODUK)
   ========================================================================== */
function initHeroCarousel() {
  const container = document.getElementById('hero-product-carousel');
  if (!container) return;

  const slides = container.querySelectorAll('.hero-carousel-slide');
  const dots = container.querySelectorAll('.hero-carousel-dot');
  const prevBtn = document.getElementById('hero-carousel-prev');
  const nextBtn = document.getElementById('hero-carousel-next');

  if (slides.length === 0) return;

  let currentIndex = 0;
  let autoplayTimer = null;

  const showSlide = (index) => {
    if (index < 0) index = slides.length - 1;
    if (index >= slides.length) index = 0;
    currentIndex = index;

    slides.forEach((slide, i) => {
      if (i === currentIndex) {
        slide.classList.remove('opacity-0', 'pointer-events-none', 'translate-x-4');
        slide.classList.add('opacity-100', 'pointer-events-auto', 'translate-x-0');
        slide.setAttribute('aria-hidden', 'false');
      } else {
        slide.classList.add('opacity-0', 'pointer-events-none', 'translate-x-4');
        slide.classList.remove('opacity-100', 'pointer-events-auto', 'translate-x-0');
        slide.setAttribute('aria-hidden', 'true');
      }
    });

    dots.forEach((dot, i) => {
      if (i === currentIndex) {
        dot.classList.add('bg-amber-400', 'w-8');
        dot.classList.remove('bg-white/40', 'w-2.5');
      } else {
        dot.classList.remove('bg-amber-400', 'w-8');
        dot.classList.add('bg-white/40', 'w-2.5');
      }
    });
  };

  const nextSlide = () => showSlide(currentIndex + 1);
  const prevSlide = () => showSlide(currentIndex - 1);

  if (prevBtn) prevBtn.addEventListener('click', () => { prevSlide(); resetAutoplay(); });
  if (nextBtn) nextBtn.addEventListener('click', () => { nextSlide(); resetAutoplay(); });

  dots.forEach((dot, i) => {
    dot.addEventListener('click', () => {
      showSlide(i);
      resetAutoplay();
    });
  });

  const startAutoplay = () => {
    if (autoplayTimer) clearInterval(autoplayTimer);
    autoplayTimer = setInterval(nextSlide, 5000);
  };

  const stopAutoplay = () => {
    if (autoplayTimer) {
      clearInterval(autoplayTimer);
      autoplayTimer = null;
    }
  };

  const resetAutoplay = () => {
    stopAutoplay();
    startAutoplay();
  };

  container.addEventListener('mouseenter', stopAutoplay);
  container.addEventListener('mouseleave', startAutoplay);

  showSlide(0);
  startAutoplay();
}

/* ==========================================================================
   6B. BCA-STYLE INTERACTIVE PRODUCT SHOWCASE (TABS, SEARCH & GRID)
   ========================================================================== */
function initProductShowcase() {
  const tabs = document.querySelectorAll('.product-showcase-tab');
  const searchInput = document.getElementById('product-showcase-search');
  const clearBtn = document.getElementById('product-showcase-search-clear');
  const grid = document.getElementById('product-showcase-grid');
  const emptyState = document.getElementById('product-showcase-empty');
  const toggleBtn = document.getElementById('product-showcase-toggle-btn');
  const toggleContainer = document.getElementById('product-showcase-toggle-container');
  const toggleText = document.getElementById('product-showcase-toggle-text');
  const toggleIcon = document.getElementById('product-showcase-toggle-icon');

  if (!grid) return;

  let activeCategory = 'all';
  let searchQuery = '';
  let isExpanded = false; // Default: hanya tampilkan 3 produk unggulan

  const getWaUrl = (prod) => {
    const defaultWa = '6281111116526';
    const waNumber = (window.DYNAMIC_SETTINGS && window.DYNAMIC_SETTINGS.whatsapp_official ? window.DYNAMIC_SETTINGS.whatsapp_official : defaultWa).replace(/[^0-9]/g, '');
    const waMsg = encodeURIComponent(`Halo Perumda BPR Majalengka, saya tertarik untuk membuka / konsultasi produk ${prod.name} (${prod.code}). Mohon informasi persyaratan dan pembukaan rekening.`);
    return `https://wa.me/${waNumber}?text=${waMsg}`;
  };

  const createCardHtml = (prod) => {
    const isKredit = prod.category === 'kredit';
    const isDeposito = prod.category === 'deposito';
    const badgeCategory = isDeposito ? 'Deposito Berjangka' : (isKredit ? 'Kredit Usaha' : 'Tabungan');
    const badgeClass = isDeposito 
      ? 'bg-amber-50 text-amber-700' 
      : (isKredit 
        ? 'bg-emerald-50 text-emerald-700' 
        : 'bg-blue-50 text-bpr-blue');
    
    const benefit1 = Array.isArray(prod.ketentuan) && prod.ketentuan[0] 
      ? prod.ketentuan[0] 
      : 'Layanan cepat dan proses mudah di 12 kantor kas';
    const benefit2 = Array.isArray(prod.ketentuan) && prod.ketentuan[1] 
      ? prod.ketentuan[1] 
      : 'Aman dan dijamin Lembaga Penjamin Simpanan (LPS)';

    const actionPrimary = isKredit
      ? `<button type="button" onclick="openFormPengajuan(null, null, '${prod.name.replace(/'/g, "\\'")}')" class="w-full py-2.5 px-4 bg-bpr-blue hover:bg-bpr-blue-hover text-white font-bold text-xs rounded-xl shadow-sm hover:shadow transition-all text-center flex items-center justify-center gap-1.5">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
          <span>Ajukan Pinjaman</span>
        </button>`
      : `<a href="${getWaUrl(prod)}" target="_blank" class="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm hover:shadow transition-all text-center flex items-center justify-center gap-1.5">
          <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z"/></svg>
          <span>Buka Rekening</span>
        </a>`;

    return `
      <div class="product-showcase-card bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm hover:shadow-xl hover:border-bpr-blue/50 transition-all flex flex-col justify-between group"
           data-category="${prod.category}"
           data-name="${(prod.name + ' ' + prod.code + ' ' + (prod.shortDesc || prod.short_desc || '')).toLowerCase()}">
        <div>
          <div class="flex items-center justify-between gap-2 mb-2">
            <span class="${badgeClass} font-bold text-xs px-2.5 py-1 rounded-lg">${badgeCategory}</span>
            <span class="font-mono text-xs text-slate-400 font-medium">${prod.code}</span>
          </div>

          <div class="h-44 rounded-xl bg-slate-50 flex items-center justify-center p-4 my-4 overflow-hidden group-hover:scale-[1.02] transition-transform">
            <img src="${prod.image}" alt="${prod.name}" class="object-contain max-h-full max-w-full" onerror="this.src='assets/img/logo.png'">
          </div>

          <h3 class="text-lg font-extrabold text-slate-900 group-hover:text-bpr-blue transition-colors line-clamp-1" title="${prod.name}">
            ${prod.name}
          </h3>

          <p class="text-xs text-slate-600 line-clamp-2 mt-1 mb-4 leading-relaxed">
            ${prod.shortDesc || prod.short_desc || ''}
          </p>

          <div class="space-y-2 mb-6 pt-1 border-t border-slate-100/80">
            <div class="text-xs text-slate-700 flex items-start gap-2">
              <svg class="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
              <span class="line-clamp-1">${benefit1}</span>
            </div>
            <div class="text-xs text-slate-700 flex items-start gap-2">
              <svg class="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
              <span class="line-clamp-1">${benefit2}</span>
            </div>
          </div>
        </div>

        <div class="pt-4 mt-auto border-t border-slate-100 flex flex-col gap-2.5">
          ${actionPrimary}
          <button type="button" onclick="showProductDetail('${prod.code}')" class="w-full py-1.5 text-xs font-bold text-bpr-blue hover:text-bpr-navy transition-colors flex items-center justify-center gap-1 group-hover:underline">
            <span>Pelajari Lebih Lanjut</span>
            <svg class="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
          </button>
        </div>
      </div>
    `;
  };

  const existingCards = grid.querySelectorAll('.product-showcase-card');
  if (existingCards.length === 0) {
    const allProds = [
      ...PRODUCTS_DATA.tabungan,
      ...PRODUCTS_DATA.deposito,
      ...PRODUCTS_DATA.kredit
    ];
    grid.innerHTML = allProds.map(createCardHtml).join('');
  }

  const filterCards = () => {
    const cards = grid.querySelectorAll('.product-showcase-card');
    const searchTerms = searchQuery ? searchQuery.split(/\s+/).filter(Boolean) : [];
    const isSearching = searchTerms.length > 0;

    let matchingCards = [];

    cards.forEach(card => {
      const cardCategory = card.dataset.category;
      const cardName = card.dataset.name || '';

      const matchCategory = (activeCategory === 'all' || cardCategory === activeCategory);
      const matchSearch = searchTerms.length === 0 || searchTerms.every(term => cardName.includes(term));

      if (matchCategory && matchSearch) {
        matchingCards.push(card);
      } else {
        card.classList.add('hidden');
      }
    });

    const totalMatching = matchingCards.length;

    if (emptyState) {
      if (totalMatching === 0) {
        emptyState.classList.remove('hidden');
      } else {
        emptyState.classList.add('hidden');
      }
    }

    // Jika sedang dalam pencarian, tampilkan semua hasil pencarian yang relevan
    if (isSearching) {
      matchingCards.forEach(card => card.classList.remove('hidden'));
      if (toggleContainer) toggleContainer.classList.add('hidden');
      return;
    }

    // Mode penjelajahan standar:
    if (!isExpanded) {
      // Hanya tampilkan 3 produk unggulan
      matchingCards.forEach((card, index) => {
        if (index < 3) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    } else {
      // Tampilkan seluruh produk
      matchingCards.forEach(card => card.classList.remove('hidden'));
    }

    // Update tombol toggle "Tampilkan Semua Produk"
    if (toggleContainer && toggleBtn) {
      if (totalMatching > 3) {
        toggleContainer.classList.remove('hidden');
        if (!isExpanded) {
          let catLabel = '';
          if (activeCategory === 'tabungan') catLabel = 'Tabungan ';
          else if (activeCategory === 'deposito') catLabel = 'Deposito ';
          else if (activeCategory === 'kredit') catLabel = 'Kredit ';
          if (toggleText) toggleText.textContent = `Tampilkan Semua Produk ${catLabel}(${totalMatching} Produk)`.replace(/\s+/g, ' ');
          if (toggleIcon) toggleIcon.classList.remove('rotate-180');
        } else {
          if (toggleText) toggleText.textContent = 'Tampilkan Lebih Sedikit (3 Produk Unggulan)';
          if (toggleIcon) toggleIcon.classList.add('rotate-180');
        }
      } else {
        toggleContainer.classList.add('hidden');
      }
    }
  };

  // Toggle button click listener
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      isExpanded = !isExpanded;
      filterCards();
      if (!isExpanded) {
        const prodSec = document.getElementById('produk');
        if (prodSec) prodSec.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }

  const applyCategoryTab = (category) => {
    activeCategory = category || 'all';
    isExpanded = false; // Reset to 3 featured products on tab switch
    tabs.forEach(t => {
      const isSelected = (t.dataset.category || 'all') === activeCategory;
      if (isSelected) {
        t.classList.add('bg-bpr-blue', 'text-white', 'shadow-sm', 'font-bold');
        t.classList.remove('text-slate-600', 'hover:text-slate-900', 'hover:bg-white/60', 'font-semibold');
        t.setAttribute('aria-selected', 'true');
      } else {
        t.classList.remove('bg-bpr-blue', 'text-white', 'shadow-sm', 'font-bold');
        t.classList.add('text-slate-600', 'hover:text-slate-900', 'hover:bg-white/60', 'font-semibold');
        t.setAttribute('aria-selected', 'false');
      }
    });
    filterCards();
  };

  // Tab click listeners
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      applyCategoryTab(tab.dataset.category || 'all');
    });
  });

  // Search input listeners
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim().toLowerCase();
      if (clearBtn) {
        if (searchQuery.length > 0) {
          clearBtn.classList.remove('hidden');
        } else {
          clearBtn.classList.add('hidden');
        }
      }
      filterCards();
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        searchInput.value = '';
        searchQuery = '';
        if (clearBtn) clearBtn.classList.add('hidden');
        filterCards();
      }
    });
  }

  // Clear button listener
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      searchQuery = '';
      clearBtn.classList.add('hidden');
      filterCards();
      if (searchInput) searchInput.focus();
    });
  }

  window.applyShowcaseCategoryTab = (category, clearSearch = false) => {
    if (clearSearch) {
      searchQuery = '';
      if (searchInput) searchInput.value = '';
      if (clearBtn) clearBtn.classList.add('hidden');
    }
    applyCategoryTab(category);
  };

  // Global reset helper
  window.resetProductFilter = function() {
    window.applyShowcaseCategoryTab('all', true);
  };

  // Programmatic tab filter helper
  window.filterProductShowcase = function(category = 'all') {
    window.applyShowcaseCategoryTab(category, false);
  };
}

/* ==========================================================================
   7. PRODUCT CATALOG & DETAIL MODAL
   (Sesuai Sketsa Halaman 3, 4, 5, 6, 7, 8)
   ========================================================================== */
function initProductModals() {
  const catalogModal = document.getElementById('modal-product-catalog');
  const catalogClose = document.getElementById('modal-catalog-close');
  const detailModal = document.getElementById('modal-product-detail');
  const detailClose = document.getElementById('modal-detail-close');
  const tabButtons = document.querySelectorAll('.catalog-tab-btn');
  const catalogSearch = document.getElementById('catalog-search-input');
  const catalogContainer = document.getElementById('catalog-cards-container');

  let activeCategory = 'all';

  // Render product cards inside catalog modal
  const renderCatalog = (filterText = '') => {
    if (!catalogContainer) return;
    catalogContainer.innerHTML = '';

    let allItems = [];
    if (activeCategory === 'all' || activeCategory === 'tabungan') allItems.push(...PRODUCTS_DATA.tabungan);
    if (activeCategory === 'all' || activeCategory === 'deposito') allItems.push(...PRODUCTS_DATA.deposito);
    if (activeCategory === 'all' || activeCategory === 'kredit') allItems.push(...PRODUCTS_DATA.kredit);

    if (filterText) {
      const q = filterText.toLowerCase();
      allItems = allItems.filter(item => 
        item.name.toLowerCase().includes(q) || 
        item.shortDesc.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q)
      );
    }

    if (allItems.length === 0) {
      catalogContainer.innerHTML = `
        <div class="col-span-full py-12 text-center text-slate-500">
          <svg class="w-12 h-12 mx-auto mb-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <p class="font-semibold">Produk tidak ditemukan</p>
          <p class="text-sm">Silakan ubah kata kunci pencarian atau ganti kategori produk.</p>
        </div>
      `;
      return;
    }

    allItems.forEach(prod => {
      const card = document.createElement('div');
      card.className = 'bg-white rounded-2xl p-6 card-shadow card-shadow-hover flex flex-col justify-between cursor-pointer group';
      card.onclick = () => showProductDetail(prod);

      const categoryLabel = prod.category === 'tabungan' ? 'Tabungan' : prod.category === 'deposito' ? 'Deposito' : 'Kredit';
      const badgeColor = prod.category === 'tabungan' ? 'bg-blue-50 text-bpr-blue font-semibold' : prod.category === 'deposito' ? 'bg-amber-50 text-amber-700 font-semibold' : 'bg-emerald-50 text-emerald-700 font-semibold';

      card.innerHTML = `
        <div>
          <div class="flex items-center justify-between mb-3">
            <span class="text-xs font-bold px-2.5 py-1 rounded-lg ${badgeColor}">${prod.badge || categoryLabel}</span>
            <span class="text-xs text-slate-400 font-mono">${prod.code}</span>
          </div>
          <div class="h-32 rounded-xl bg-slate-50 flex items-center justify-center p-3 mb-4 overflow-hidden group-hover:scale-[1.02] transition-transform">
            <img src="${prod.image}" alt="${prod.name}" class="max-h-full max-w-full object-contain" onerror="this.src='assets/img/logo.png'">
          </div>
          <h4 class="font-bold text-slate-900 group-hover:text-bpr-blue transition-colors text-base mb-1.5 leading-snug">${prod.name}</h4>
          <p class="text-slate-500 text-xs line-clamp-3 mb-4 leading-relaxed">${prod.shortDesc || prod.short_desc || ''}</p>
        </div>
        <div class="pt-3 mt-auto flex items-center justify-between">
          <span class="text-xs font-semibold text-bpr-blue group-hover:underline">
            Selengkapnya
          </span>
          <span class="text-xs text-slate-400 font-medium">BPR Majalengka</span>
        </div>
      `;
      catalogContainer.appendChild(card);
    });
  };

  // Tab switcher
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => {
        b.classList.remove('bg-bpr-navy', 'text-white');
        b.classList.add('bg-slate-100', 'text-slate-600');
      });
      btn.classList.remove('bg-slate-100', 'text-slate-600');
      btn.classList.add('bg-bpr-navy', 'text-white');
      activeCategory = btn.dataset.category;
      renderCatalog(catalogSearch ? catalogSearch.value : '');
    });
  });

  // Search input
  if (catalogSearch) {
    catalogSearch.addEventListener('input', (e) => {
      renderCatalog(e.target.value);
    });
  }

  // Close catalog
  if (catalogClose) {
    catalogClose.addEventListener('click', () => {
      catalogModal.classList.remove('active');
      const anyActive = document.querySelector('.modal-backdrop.active');
      if (!anyActive) {
        document.body.classList.remove('overflow-hidden');
      }
    });
  }

  // Back button from detail to catalog
  const detailBack = document.getElementById('modal-detail-back');
  if (detailBack) {
    detailBack.addEventListener('click', () => {
      detailModal.classList.remove('active');
      if (catalogModal && catalogModal.classList.contains('was-open')) {
        catalogModal.classList.add('active');
        catalogModal.classList.remove('was-open');
        document.body.classList.add('overflow-hidden');
      } else {
        const anyActive = document.querySelector('.modal-backdrop.active');
        if (!anyActive) {
          document.body.classList.remove('overflow-hidden');
        }
      }
    });
  }

  // Close detail
  if (detailClose) {
    detailClose.addEventListener('click', () => {
      detailModal.classList.remove('active');
      if (catalogModal) catalogModal.classList.remove('was-open');
      const anyActive = document.querySelector('.modal-backdrop.active');
      if (!anyActive) {
        document.body.classList.remove('overflow-hidden');
      }
    });
  }
}

/* ==========================================================================
   8. NEWS & LITERASI DETAIL MODAL
   ========================================================================== */
function initNewsModal() {
  const newsModal = document.getElementById('modal-news-reader');
  const newsClose = document.getElementById('modal-news-close');

  if (newsClose && newsModal) {
    newsClose.addEventListener('click', () => {
      newsModal.classList.remove('active');
      const anyActive = document.querySelector('.modal-backdrop.active');
      if (!anyActive) {
        document.body.classList.remove('overflow-hidden');
      }
    });
  }

  const allNewsClose = document.getElementById('modal-all-news-close');
  if (allNewsClose) {
    allNewsClose.addEventListener('click', () => {
      const allNewsModal = document.getElementById('modal-all-news');
      if (allNewsModal) allNewsModal.classList.remove('active');
      const anyActive = document.querySelector('.modal-backdrop.active');
      if (!anyActive) {
        document.body.classList.remove('overflow-hidden');
      }
    });
  }
}

/* ==========================================================================
   9. ACCORDION FAQ LOGIC (Sesuai Sketsa Halaman 12)
   ========================================================================== */
function initFAQ() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const trigger = item.querySelector('.faq-trigger');
    const answer = item.querySelector('.faq-answer');
    const icon = item.querySelector('.faq-icon');

    if (!trigger || !answer) return;

    trigger.addEventListener('click', () => {
      const isOpen = !answer.classList.contains('hidden');

      // Close all other accordions
      document.querySelectorAll('.faq-answer').forEach(ans => ans.classList.add('hidden'));
      document.querySelectorAll('.faq-icon').forEach(ic => {
        ic.classList.remove('rotate-45');
      });

      if (!isOpen) {
        answer.classList.remove('hidden');
        if (icon) icon.classList.add('rotate-45');
      }
    });
  });
}

/* ==========================================================================
   10. KANTOR KAS DIRECTORY & FILE SYSTEM
   ========================================================================== */
function toggleBranchesDirectory(forceOpen = null) {
  const content = document.getElementById('branches-directory-content');
  const btnText = document.getElementById('btn-toggle-branches-text');
  const icon = document.getElementById('branches-toggle-icon');
  if (!content) return;

  const isHidden = content.classList.contains('hidden');
  const shouldOpen = forceOpen !== null ? forceOpen : isHidden;

  if (shouldOpen) {
    content.classList.remove('hidden');
    if (btnText) btnText.textContent = 'Tutup Daftar Kantor Cabang';
    if (icon) icon.classList.add('rotate-180');
  } else {
    content.classList.add('hidden');
    if (btnText) btnText.textContent = 'Lihat Kantor Cabang Lainnya';
    if (icon) icon.classList.remove('rotate-180');
  }
}

function initKantorKas() {
  const container = document.getElementById('kantor-kas-grid');
  const searchInput = document.getElementById('kantor-kas-search');

  if (!container) return;

  const existingCards = container.querySelectorAll('.kantor-kas-card');

  const filterExisting = (query = '') => {
    const q = query.trim().toLowerCase();
    if (q) {
      toggleBranchesDirectory(true);
    }
    let visibleCount = 0;
    existingCards.forEach(card => {
      const name = card.dataset.name || '';
      const address = card.dataset.address || '';
      if (!q || name.includes(q) || address.includes(q)) {
        card.style.display = '';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });

    let noResultsEl = document.getElementById('kantor-kas-no-results');
    if (visibleCount === 0) {
      if (!noResultsEl) {
        noResultsEl = document.createElement('div');
        noResultsEl.id = 'kantor-kas-no-results';
        noResultsEl.className = 'col-span-1 sm:col-span-2 lg:col-span-3 text-center py-12 text-slate-400 text-sm';
        noResultsEl.textContent = 'Tidak ditemukan kantor cabang untuk pencarian "' + query + '".';
        container.appendChild(noResultsEl);
      }
      noResultsEl.style.display = '';
    } else if (noResultsEl) {
      noResultsEl.style.display = 'none';
    }
  };

  const renderFromData = (query = '') => {
    container.innerHTML = '';
    // Kantor Pusat ditampilkan khusus di Headline; grid menampilkan kantor cabang lainnya.
    let branchesToRender = BRANCHES_DATA.filter(b => !(b.isMain || b.is_main));
    if (branchesToRender.length === 0) branchesToRender = BRANCHES_DATA;

    let filtered = branchesToRender;
    if (query) {
      toggleBranchesDirectory(true);
      const q = query.toLowerCase();
      filtered = branchesToRender.filter(b => 
        (b.name || '').toLowerCase().includes(q) || 
        (b.address || '').toLowerCase().includes(q)
      );
    }

    if (filtered.length === 0) {
      container.innerHTML = `<div class="col-span-1 sm:col-span-2 lg:col-span-3 text-center py-12 text-slate-400 text-sm">Tidak ditemukan kantor cabang untuk pencarian "${query}".</div>`;
      return;
    }

    filtered.forEach(branch => {
      const isMain = branch.isMain || branch.is_main || false;
      const branchType = branch.type || (isMain ? 'Pusat' : 'Cabang');
      const branchHours = branch.hours || branch.operational_hours || 'Senin - Jumat: 08:00 - 15:30 WIB';
      const branchPhone = branch.phone || '(0233) 281144';
      const waNumber = (branch.whatsapp || '081111116526').replace(/[^0-9]/g, '');
      const hasCoordinates = branch.latitude !== null && branch.latitude !== undefined && branch.latitude !== ''
        && branch.longitude !== null && branch.longitude !== undefined && branch.longitude !== '';
      const mapsUrl = hasCoordinates
        ? `https://www.google.com/maps?q=${branch.latitude},${branch.longitude}`
        : `https://www.google.com/maps?q=${encodeURIComponent(branch.name + ' ' + branch.address)}`;

      const card = document.createElement('div');
      card.className = `kantor-kas-card bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group`;
      card.dataset.name = (branch.name || '').toLowerCase();
      card.dataset.address = (branch.address || '').toLowerCase();
      card.innerHTML = `
        <div>
          <div class="flex items-center justify-between mb-2">
            <span class="text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 flex items-center gap-1">
              <svg class="w-3.5 h-3.5 text-bpr-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
              <span>${branchType}</span>
            </span>
            <span class="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span>Buka Layanan</span>
            </span>
          </div>
          <h4 class="font-bold text-slate-900 text-base mb-1.5 group-hover:text-bpr-blue transition-colors">${branch.name}</h4>
          <p class="text-slate-600 text-xs mb-3 leading-relaxed flex items-start gap-1.5">
            <svg class="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            <span>${branch.address}</span>
          </p>
          <div class="text-xs text-slate-500 space-y-1 mb-4 pt-2 border-t border-slate-100 font-mono text-[11px]">
            <p><strong class="font-sans font-semibold text-slate-700">Tel:</strong> ${branchPhone}</p>
            <p><strong class="font-sans font-semibold text-slate-700">Jam:</strong> ${branchHours}</p>
          </div>
        </div>
        <div class="flex items-center gap-2 pt-2">
          <a href="https://wa.me/${waNumber}?text=${encodeURIComponent('Halo ' + branch.name + ', saya butuh informasi layanan BPR.')}" target="_blank" class="flex-1 text-center py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors">
            <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z"/></svg>
            Hubungi Kas
          </a>
          <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" aria-label="Lihat lokasi ${branch.name} di Google Maps" class="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors">
            <svg class="w-4 h-4 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
            <span>Lihat Peta</span>
          </a>
        </div>
      `;
      container.appendChild(card);
    });
  };

  if (existingCards.length > 0) {
    if (searchInput) {
      searchInput.addEventListener('input', (e) => filterExisting(e.target.value));
    }
  } else {
    renderFromData();
    if (searchInput) {
      searchInput.addEventListener('input', (e) => renderFromData(e.target.value));
    }
  }
}

/* ==========================================================================
   11. KOLOM TANYA & PENCARIAN CEPAT (Sesuai Sketsa Halaman 1)
   ========================================================================== */
function initKolomTanya() {
  const searchInput = document.getElementById('hero-search-input');
  const searchBtn = document.getElementById('hero-search-btn');
  const resultsDropdown = document.getElementById('hero-search-results');
  if (!searchInput || !resultsDropdown) return;

  const performSearch = (query) => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) {
      resultsDropdown.classList.add('hidden');
      resultsDropdown.innerHTML = '';
      return;
    }

    const allProducts = [
      ...PRODUCTS_DATA.tabungan,
      ...PRODUCTS_DATA.deposito,
      ...PRODUCTS_DATA.kredit
    ];

    const matchedProducts = allProducts.filter(p => 
      (p.name || '').toLowerCase().includes(q) ||
      (p.slogan || '').toLowerCase().includes(q) ||
      ((p.shortDesc || p.short_desc) || '').toLowerCase().includes(q) ||
      (p.code || '').toLowerCase().includes(q) ||
      (p.category || '').toLowerCase().includes(q)
    );

    const matchedBranches = BRANCHES_DATA.filter(b => 
      (b.name || '').toLowerCase().includes(q) || 
      (b.address || '').toLowerCase().includes(q)
    );

    const matchedArticles = ARTICLES_DATA.filter(a =>
      (a.title || '').toLowerCase().includes(q) ||
      (a.tag || a.category || '').toLowerCase().includes(q)
    );

    let html = '';

    if (matchedProducts.length > 0) {
      html += `<div class="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider bg-slate-50 rounded-lg mb-1">Produk Perbankan (${matchedProducts.length})</div>`;
      matchedProducts.slice(0, 4).forEach(p => {
        html += `
          <div class="search-result-item flex items-center justify-between p-2.5 hover:bg-blue-50/70 rounded-xl cursor-pointer transition-colors" data-type="product" data-id="${p.id}">
            <div class="flex items-center gap-2.5">
              <span class="w-7 h-7 rounded-lg bg-blue-100 text-bpr-blue text-xs font-bold flex items-center justify-center">${p.category === 'tabungan' ? 'TAB' : p.category === 'deposito' ? 'DEP' : 'KRD'}</span>
              <div>
                <p class="text-xs font-bold text-slate-800">${p.name}</p>
                <p class="text-[11px] text-slate-500">${p.badge || p.code} • ${p.category.toUpperCase()}</p>
              </div>
            </div>
            <span class="text-xs text-bpr-blue font-semibold">Lihat Detail</span>
          </div>
        `;
      });
    }

    if (matchedBranches.length > 0) {
      html += `<div class="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider bg-slate-50 rounded-lg my-1">Kantor Kas (${matchedBranches.length})</div>`;
      matchedBranches.slice(0, 3).forEach(b => {
        html += `
          <div class="search-result-item flex items-center justify-between p-2.5 hover:bg-emerald-50/70 rounded-xl cursor-pointer transition-colors" data-type="branch" data-name="${b.name}">
            <div class="flex items-center gap-2.5">
              <span class="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center justify-center">KAS</span>
              <div>
                <p class="text-xs font-bold text-slate-800">${b.name}</p>
                <p class="text-[11px] text-slate-500">${b.address.slice(0, 45)}...</p>
              </div>
            </div>
            <span class="text-xs text-emerald-600 font-semibold">Lihat Lokasi</span>
          </div>
        `;
      });
    }

    if (matchedArticles.length > 0) {
      html += `<div class="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider bg-slate-50 rounded-lg my-1">Edukasi Finansial (${matchedArticles.length})</div>`;
      matchedArticles.slice(0, 2).forEach(a => {
        html += `
          <div class="search-result-item flex items-center justify-between p-2.5 hover:bg-amber-50/70 rounded-xl cursor-pointer transition-colors" data-type="article" data-id="${a.id}">
            <div class="flex items-center gap-2.5">
              <span class="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 text-xs font-bold flex items-center justify-center">EDU</span>
              <div>
                <p class="text-xs font-bold text-slate-800">${a.title}</p>
                <p class="text-[11px] text-slate-500">${a.tag || a.category || 'Literasi'}</p>
              </div>
            </div>
            <span class="text-xs text-amber-600 font-semibold">Baca Artikel</span>
          </div>
        `;
      });
    }

    if (!html) {
      html = `
        <div class="py-6 text-center text-slate-500">
          <p class="text-xs font-semibold">Tidak ada hasil untuk "${query}"</p>
          <p class="text-[11px] text-slate-400 mt-1">Coba kata kunci: TAHARA, Deposito, Kredit PERAK, Kadipaten, atau Dana Darurat.</p>
        </div>
      `;
    }

    resultsDropdown.innerHTML = html;
    resultsDropdown.classList.remove('hidden');

    resultsDropdown.querySelectorAll('.search-result-item').forEach(item => {
      item.addEventListener('click', () => {
        const type = item.dataset.type;
        if (type === 'product') {
          const prodId = item.dataset.id;
          const prod = allProducts.find(p => p.id == prodId || p.slug === prodId || p.code === prodId);
          if (prod) {
            resultsDropdown.classList.add('hidden');
            showProductDetail(prod);
          }
        } else if (type === 'branch') {
          resultsDropdown.classList.add('hidden');
          const branchSection = document.getElementById('kantor-kas');
          if (branchSection) {
            branchSection.scrollIntoView({ behavior: 'smooth' });
            if (typeof toggleBranchesDirectory === 'function') {
              toggleBranchesDirectory(true);
            }
            const kasSearch = document.getElementById('kantor-kas-search');
            if (kasSearch) {
              kasSearch.value = item.dataset.name.replace('Kantor Kas ', '');
              kasSearch.dispatchEvent(new Event('input'));
            }
          }
        } else if (type === 'article') {
          const artId = item.dataset.id;
          const art = ARTICLES_DATA.find(a => a.id == artId || a.slug === artId);
          resultsDropdown.classList.add('hidden');
          if (art) {
            readArticle(art.id);
          }
        }
      });
    });
  };

  searchInput.addEventListener('input', (e) => {
    performSearch(e.target.value);
  });

  if (searchBtn) {
    searchBtn.addEventListener('click', () => {
      performSearch(searchInput.value);
    });
  }

  document.addEventListener('click', (e) => {
    if (!searchInput.contains(e.target) && !resultsDropdown.contains(e.target)) {
      resultsDropdown.classList.add('hidden');
    }
  });
}

/* ==========================================================================
   12. LAPORAN PUBLIKASI ARCHIVE, PREVIEW & SEARCH
   ========================================================================== */
const REPORT_ARCHIVES_DATA = {
  triwulan: {
    categoryKey: 'triwulan',
    categoryName: 'Laporan Keuangan Publikasi Triwulanan',
    badge: 'Neraca Berkala OJK',
    badgeClass: 'bg-blue-50 text-bpr-blue',
    description: 'Neraca dan laporan publikasi berkala per triwulan/bulan yang disampaikan kepada Otoritas Jasa Keuangan (OJK) dan Lembaga Penjamin Simpanan (LPS).',
    files: [
      {
        id: 'triwulan-2024-q3',
        month: 'September 2024',
        quarter: 'Triwulan III',
        year: '2024',
        title: 'Laporan Publikasi Keuangan Posisi 30 September 2024',
        period: 'Triwulan III - 30 September 2024',
        size: '1.8 MB',
        filePath: 'assets/docs/laporan-publikasi-q3-2024.pdf',
        pages: '6 Halaman',
        datePublished: '15 Oktober 2024',
        summary: 'Posisi neraca keuangan triwulan III 2024 menunjukkan rasio kecukupan modal CAR 24.8%, NPL Net 1.82%, pertumbuhan DPK 8.4%, serta likuiditas sehat terverifikasi OJK.'
      },
      {
        id: 'triwulan-2024-q2',
        month: 'Juni 2024',
        quarter: 'Triwulan II (Semester I)',
        year: '2024',
        title: 'Laporan Publikasi Keuangan Posisi 30 Juni 2024',
        period: 'Triwulan II - 30 Juni 2024',
        size: '1.6 MB',
        filePath: 'assets/docs/laporan-publikasi-q2-2024.pdf',
        pages: '6 Halaman',
        datePublished: '18 Juli 2024',
        summary: 'Laporan posisi keuangan semester I 2024 mencerminkan likuiditas yang kuat, rasio KPMM/CAR di atas ketentuan regulasi, serta efisiensi beban operasional terkendali.'
      },
      {
        id: 'triwulan-2024-q1',
        month: 'Maret 2024',
        quarter: 'Triwulan I',
        year: '2024',
        title: 'Laporan Publikasi Keuangan Posisi 31 Maret 2024',
        period: 'Triwulan I - 31 Maret 2024',
        size: '1.5 MB',
        filePath: 'assets/docs/laporan-publikasi-q2-2024.pdf',
        pages: '6 Halaman',
        datePublished: '16 April 2024',
        summary: 'Realisasi kinerja awal triwulan I 2024 dengan ekspansi penyaluran kredit produktif UMKM dan stabilitas penghimpunan dana simpanan masyarakat Majalengka.'
      },
      {
        id: 'triwulan-2023-q4',
        month: 'Desember 2023',
        quarter: 'Triwulan IV (Tahunan)',
        year: '2023',
        title: 'Laporan Publikasi Keuangan Posisi 31 Desember 2023',
        period: 'Triwulan IV - 31 Desember 2023',
        size: '1.9 MB',
        filePath: 'assets/docs/laporan-publikasi-q3-2024.pdf',
        pages: '8 Halaman',
        datePublished: '25 Januari 2024',
        summary: 'Laporan penutupan buku tahun 2023 dengan penguatan struktur modal, cadangan CKPN, dan hasil penggabungan (merger) 8 BPR Kabupaten Majalengka.'
      },
      {
        id: 'triwulan-2023-q3',
        month: 'September 2023',
        quarter: 'Triwulan III',
        year: '2023',
        title: 'Laporan Publikasi Keuangan Posisi 30 September 2023',
        period: 'Triwulan III - 30 September 2023',
        size: '1.7 MB',
        filePath: 'assets/docs/laporan-publikasi-q3-2024.pdf',
        pages: '6 Halaman',
        datePublished: '17 Oktober 2023',
        summary: 'Neraca triwulan III 2023 mencatatkan rasio kecukupan modal yang solid pasca penggabungan konsolidasi 8 BPR Majalengka.'
      },
      {
        id: 'triwulan-2023-q2',
        month: 'Juni 2023',
        quarter: 'Triwulan II',
        year: '2023',
        title: 'Laporan Publikasi Keuangan Posisi 30 Juni 2023',
        period: 'Triwulan II - 30 Juni 2023',
        size: '1.6 MB',
        filePath: 'assets/docs/laporan-publikasi-q2-2024.pdf',
        pages: '6 Halaman',
        datePublished: '20 Juli 2023',
        summary: 'Kinerja semester I 2023 membuktikan ketahanan portofolio kredit mikro di 12 wilayah kantor kas Kabupaten Majalengka.'
      }
    ]
  },
  audited: {
    categoryKey: 'audited',
    categoryName: 'Laporan Keuangan Tahunan (Audited)',
    badge: 'Audit KAP Independen',
    badgeClass: 'bg-amber-50 text-amber-800',
    description: 'Laporan keuangan tahunan yang telah diaudit oleh Kantor Akuntan Publik (KAP) independen dengan opini Wajar Tanpa Pengecualian (WTP).',
    files: [
      {
        id: 'audited-2023',
        month: 'Tahun 2023',
        quarter: 'Tahunan Penuh',
        year: '2023',
        title: 'Laporan Keuangan Audited Tahun Buku 2023',
        period: 'Tahun Buku 2023 (1 Jan - 31 Des 2023)',
        size: '4.5 MB',
        filePath: 'assets/docs/laporan-audited-2023.pdf',
        pages: '48 Halaman',
        datePublished: '15 April 2024',
        summary: 'Laporan audit KAP independen dengan opini Wajar Tanpa Pengecualian (WTP). Memuat neraca komparatif, laba rugi, arus kas, dan catatan atas laporan keuangan.'
      },
      {
        id: 'audited-2022',
        month: 'Tahun 2022',
        quarter: 'Tahunan Penuh',
        year: '2022',
        title: 'Laporan Keuangan Audited Tahun Buku 2022',
        period: 'Tahun Buku 2022 (1 Jan - 31 Des 2022)',
        size: '4.2 MB',
        filePath: 'assets/docs/laporan-audited-2023.pdf',
        pages: '44 Halaman',
        datePublished: '20 April 2023',
        summary: 'Laporan audit keuangan komprehensif periode transisi merger BPR Kabupaten Majalengka dengan opini audit independen tanpa modifikasi.'
      },
      {
        id: 'audited-2021',
        month: 'Tahun 2021',
        quarter: 'Tahunan Penuh',
        year: '2021',
        title: 'Laporan Keuangan Audited Tahun Buku 2021',
        period: 'Tahun Buku 2021 (1 Jan - 31 Des 2021)',
        size: '3.8 MB',
        filePath: 'assets/docs/laporan-audited-2023.pdf',
        pages: '40 Halaman',
        datePublished: '28 April 2022',
        summary: 'Hasil audit independen laporan keuangan tahun 2021 menunjukkan kepatuhan tinggi terhadap Standar Akuntansi Keuangan SAK ETAP.'
      }
    ]
  },
  gcg: {
    categoryKey: 'gcg',
    categoryName: 'Laporan Penerapan Tata Kelola Perusahaan (GCG)',
    badge: 'Good Corporate Governance',
    badgeClass: 'bg-emerald-50 text-emerald-700',
    description: 'Laporan transparansi pelaksanaan tata kelola yang baik (transparency, accountability, responsibility, independency, fairness) sesuai SEOJK.',
    files: [
      {
        id: 'gcg-2023',
        month: 'Tahun 2023',
        quarter: 'Tahunan GCG',
        year: '2023',
        title: 'Laporan Pelaksanaan Tata Kelola (GCG) Tahun 2023',
        period: 'Tahun 2023',
        size: '3.2 MB',
        filePath: 'assets/docs/laporan-gcg-2023.pdf',
        pages: '32 Halaman',
        datePublished: '30 Mei 2024',
        summary: 'Penilaian mandiri (self assessment) pelaksanaan GCG dengan predikat "SANGAT BAIK". Menguraikan kepengurusan, remunerasi, komite audit, dan sistem pengendalian intern.'
      },
      {
        id: 'gcg-2022',
        month: 'Tahun 2022',
        quarter: 'Tahunan GCG',
        year: '2022',
        title: 'Laporan Pelaksanaan Tata Kelola (GCG) Tahun 2022',
        period: 'Tahun 2022',
        size: '3.0 MB',
        filePath: 'assets/docs/laporan-gcg-2023.pdf',
        pages: '28 Halaman',
        datePublished: '25 Mei 2023',
        summary: 'Implementasi tata kelola dalam integrasi manajemen operasional paska merger 8 BPR Kabupaten Majalengka.'
      },
      {
        id: 'gcg-2021',
        month: 'Tahun 2021',
        quarter: 'Tahunan GCG',
        year: '2021',
        title: 'Laporan Pelaksanaan Tata Kelola (GCG) Tahun 2021',
        period: 'Tahun 2021',
        size: '2.8 MB',
        filePath: 'assets/docs/laporan-gcg-2023.pdf',
        pages: '26 Halaman',
        datePublished: '31 Mei 2022',
        summary: 'Kepatuhan tata kelola direksi dan dewan pengawas serta efektivitas fungsi kepatuhan dan manajemen risiko perbankan daerah.'
      }
    ]
  },
  rakb: {
    categoryKey: 'rakb',
    categoryName: 'Rencana Aksi Keuangan Berkelanjutan (RAKB)',
    badge: 'Keuangan Berkelanjutan',
    badgeClass: 'bg-purple-50 text-purple-700',
    description: 'Penerapan prinsip keuangan berkelanjutan berbasis POJK No. 51/POJK.03/2017 dalam mendukung pertumbuhan ekonomi hijau dan pemberdayaan masyarakat.',
    files: [
      {
        id: 'rakb-2024-2025',
        month: 'Periode 2024-2025',
        quarter: 'Rencana Aksi',
        year: '2024',
        title: 'Rencana Aksi Keuangan Berkelanjutan (RAKB) 2024 - 2025',
        period: 'Tahun 2024 - 2025',
        size: '2.1 MB',
        filePath: 'assets/docs/laporan-rakb-2024.pdf',
        pages: '24 Halaman',
        datePublished: '10 Januari 2024',
        summary: 'Rencana strategis alokasi pembiayaan usaha ramah lingkungan, pertanian terpadu Majalengka, dan efisiensi operasional perbankan ramah energi.'
      },
      {
        id: 'rakb-realisasi-2023',
        month: 'Realisasi 2023',
        quarter: 'Realisasi Tahunan',
        year: '2023',
        title: 'Laporan Realisasi Keuangan Berkelanjutan Tahun 2023',
        period: 'Tahun 2023',
        size: '1.9 MB',
        filePath: 'assets/docs/laporan-rakb-2024.pdf',
        pages: '20 Halaman',
        datePublished: '28 Februari 2024',
        summary: 'Realisasi penyaluran kredit produktif mikro berkelanjutan kepada 1.400+ pelaku usaha mikro daerah dan program CSR peduli kelestarian alam.'
      }
    ]
  },
  audit_internal: {
    categoryKey: 'audit_internal',
    categoryName: 'Piagam Audit Internal (Audit Charter)',
    badge: 'Pengawasan Internal',
    badgeClass: 'bg-slate-100 text-slate-700',
    description: 'Piagam dan standar operasional Satuan Kerja Audit Intern (SKAI) yang disahkan oleh Direksi dan Dewan Pengawas.',
    files: [
      {
        id: 'audit-charter-2024',
        month: 'Edisi 2024',
        quarter: 'Revisi Terkini',
        year: '2024',
        title: 'Piagam Audit Internal (Audit Charter) Tahun 2024',
        period: 'Edisi 2024',
        size: '1.2 MB',
        filePath: 'assets/docs/piagam-audit-internal.pdf',
        pages: '18 Halaman',
        datePublished: '02 Januari 2024',
        summary: 'Pedoman formal kewenangan, tanggung jawab, independensi, dan objektivitas satuan pengawasan intern dalam memitigasi risiko operasional perbankan.'
      },
      {
        id: 'audit-sop-2023',
        month: 'Edisi 2023',
        quarter: 'Standar Operasional',
        year: '2023',
        title: 'Standar Operasional Prosedur Pengawasan Intern 2023',
        period: 'Edisi 2023',
        size: '1.1 MB',
        filePath: 'assets/docs/piagam-audit-internal.pdf',
        pages: '16 Halaman',
        datePublished: '05 Januari 2023',
        summary: 'Kerangka kerja audit berbasis risiko (risk-based audit) untuk pemeriksaan teratur pada 12 kantor kas dan unit operasional kantor pusat.'
      }
    ]
  }
};

let currentArchiveGroup = null;
let currentArchiveYear = 'all';
let currentSelectedFile = null;

function resolveArchiveGroup(keyOrId) {
  if (!keyOrId) return { group: REPORT_ARCHIVES_DATA.triwulan, defaultFileId: 'triwulan-2024-q3' };
  const str = String(keyOrId).toLowerCase().trim();

  if (str === '1' || str.includes('september') || str.includes('triwulan iii') || str.includes('q3')) {
    return { group: REPORT_ARCHIVES_DATA.triwulan, defaultFileId: 'triwulan-2024-q3' };
  }
  if (str === '2' || str.includes('juni') || str.includes('triwulan ii') || str.includes('q2')) {
    return { group: REPORT_ARCHIVES_DATA.triwulan, defaultFileId: 'triwulan-2024-q2' };
  }
  if (str === '3' || str.includes('gcg') || str.includes('tata kelola')) {
    return { group: REPORT_ARCHIVES_DATA.gcg, defaultFileId: 'gcg-2023' };
  }
  if (str === '4' || str.includes('audited') || str.includes('tahunan audited') || str.includes('kap')) {
    return { group: REPORT_ARCHIVES_DATA.audited, defaultFileId: 'audited-2023' };
  }
  if (str === '5' || str.includes('rakb') || str.includes('keuangan berkelanjutan')) {
    return { group: REPORT_ARCHIVES_DATA.rakb, defaultFileId: 'rakb-2024-2025' };
  }
  if (str === '6' || str.includes('audit internal') || str.includes('charter') || str.includes('piagam')) {
    return { group: REPORT_ARCHIVES_DATA.audit_internal, defaultFileId: 'audit-charter-2024' };
  }

  if (REPORT_ARCHIVES_DATA[str]) {
    return { group: REPORT_ARCHIVES_DATA[str], defaultFileId: REPORT_ARCHIVES_DATA[str].files[0].id };
  }

  return { group: REPORT_ARCHIVES_DATA.triwulan, defaultFileId: 'triwulan-2024-q3' };
}

function openReportArchive(reportIdOrKey, specificFileId = null) {
  const modal = document.getElementById('modal-laporan-preview');
  if (!modal) return;

  const resolved = resolveArchiveGroup(reportIdOrKey);
  currentArchiveGroup = resolved.group;
  currentArchiveYear = 'all';

  const catBadge = document.getElementById('report-modal-category-badge');
  const mainTitle = document.getElementById('report-modal-main-title');
  if (catBadge) catBadge.textContent = currentArchiveGroup.badge;
  if (mainTitle) mainTitle.textContent = currentArchiveGroup.categoryName;

  // Reset year filter tabs
  const tabs = document.querySelectorAll('.report-year-tab');
  tabs.forEach(tab => {
    if (tab.dataset.year === 'all') {
      tab.classList.add('bg-white', 'text-bpr-blue', 'shadow-sm', 'font-bold');
      tab.classList.remove('text-slate-600', 'font-medium');
    } else {
      tab.classList.remove('bg-white', 'text-bpr-blue', 'shadow-sm', 'font-bold');
      tab.classList.add('text-slate-600', 'font-medium');
    }
  });

  renderArchiveFilesList(specificFileId || resolved.defaultFileId);

  modal.classList.add('active');
  document.body.classList.add('overflow-hidden');
}

function closeReportArchiveModal() {
  const modal = document.getElementById('modal-laporan-preview');
  if (modal) modal.classList.remove('active');
  const anyActive = document.querySelector('.modal-backdrop.active');
  if (!anyActive) {
    document.body.classList.remove('overflow-hidden');
  }
}

function filterReportArchiveYear(year) {
  currentArchiveYear = year;
  const tabs = document.querySelectorAll('.report-year-tab');
  tabs.forEach(tab => {
    if (tab.dataset.year === year) {
      tab.classList.add('bg-white', 'text-bpr-blue', 'shadow-sm', 'font-bold');
      tab.classList.remove('text-slate-600', 'font-medium');
    } else {
      tab.classList.remove('bg-white', 'text-bpr-blue', 'shadow-sm', 'font-bold');
      tab.classList.add('text-slate-600', 'font-medium');
    }
  });

  renderArchiveFilesList(currentSelectedFile ? currentSelectedFile.id : null);
}

function renderArchiveFilesList(activeFileId = null) {
  const container = document.getElementById('report-files-list-container');
  if (!container || !currentArchiveGroup) return;

  container.innerHTML = '';

  let files = currentArchiveGroup.files;
  if (currentArchiveYear !== 'all') {
    files = files.filter(f => f.year === currentArchiveYear);
  }

  if (files.length === 0) {
    container.innerHTML = `<div class="py-8 text-center text-slate-400 text-xs">Tidak ada arsip dokumen untuk tahun ${currentArchiveYear}.</div>`;
    return;
  }

  let fileToSelect = files.find(f => f.id === activeFileId) || files[0];

  files.forEach(file => {
    const isSelected = file.id === fileToSelect.id;
    const item = document.createElement('div');
    item.className = `report-file-item p-3 rounded-2xl cursor-pointer transition-all border ${
      isSelected 
        ? 'bg-blue-50/70 border-bpr-blue/40 shadow-sm ring-1 ring-bpr-blue/30' 
        : 'bg-white border-slate-200/80 hover:bg-slate-100/70 hover:border-slate-300'
    }`;
    item.dataset.id = file.id;
    item.innerHTML = `
      <div class="flex items-center justify-between mb-1">
        <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-md ${
          isSelected ? 'bg-bpr-blue text-white' : 'bg-slate-100 text-slate-600'
        }">${file.quarter || file.month}</span>
        <span class="text-[11px] font-mono text-slate-400">${file.size}</span>
      </div>
      <h6 class="text-xs font-bold ${isSelected ? 'text-bpr-blue' : 'text-slate-800'} line-clamp-1">${file.title}</h6>
      <div class="mt-1 flex items-center justify-between text-[11px] text-slate-400">
        <span>${file.month}</span>
        <span class="text-[10px] font-semibold text-emerald-700 ${isSelected ? 'flex items-center gap-1' : 'hidden'}">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          Aktif
        </span>
      </div>
    `;

    item.addEventListener('click', () => {
      selectReportArchiveFile(file.id);
    });

    container.appendChild(item);
  });

  selectReportArchiveFile(fileToSelect.id, false);
}

function selectReportArchiveFile(fileId, updateList = true) {
  if (!currentArchiveGroup) return;
  const file = currentArchiveGroup.files.find(f => f.id === fileId);
  if (!file) return;

  currentSelectedFile = file;

  if (updateList) {
    const items = document.querySelectorAll('.report-file-item');
    items.forEach(it => {
      const isSelected = it.dataset.id === fileId;
      if (isSelected) {
        it.className = 'report-file-item p-3 rounded-2xl cursor-pointer transition-all border bg-blue-50/70 border-bpr-blue/40 shadow-sm ring-1 ring-bpr-blue/30';
        const b = it.querySelector('span');
        if (b) { b.className = 'text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-bpr-blue text-white'; }
        const h = it.querySelector('h6');
        if (h) { h.className = 'text-xs font-bold text-bpr-blue line-clamp-1'; }
        const status = it.querySelector('.text-emerald-700');
        if (status) status.classList.remove('hidden');
      } else {
        it.className = 'report-file-item p-3 rounded-2xl cursor-pointer transition-all border bg-white border-slate-200/80 hover:bg-slate-100/70 hover:border-slate-300';
        const b = it.querySelector('span');
        if (b) { b.className = 'text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600'; }
        const h = it.querySelector('h6');
        if (h) { h.className = 'text-xs font-bold text-slate-800 line-clamp-1'; }
        const status = it.querySelector('.text-emerald-700');
        if (status) status.classList.add('hidden');
      }
    });
  }

  // Populate Preview details
  const pBadge = document.getElementById('preview-file-period-badge');
  const pTitle = document.getElementById('preview-file-title');
  const pSize = document.getElementById('preview-file-size');
  const pDate = document.getElementById('preview-file-date');
  const pSummary = document.getElementById('preview-file-summary');
  const pPages = document.getElementById('preview-file-pages');
  const pIframe = document.getElementById('preview-pdf-iframe');
  const pDownloadBtn = document.getElementById('preview-download-btn');
  const pDownloadText = document.getElementById('preview-download-text');
  const pOpenTabBtn = document.getElementById('preview-open-tab-btn');

  if (pBadge) pBadge.textContent = file.period || file.quarter;
  if (pTitle) pTitle.textContent = file.title;
  if (pSize) pSize.textContent = file.size;
  if (pDate) pDate.textContent = `Dipublikasikan resmi pada ${file.datePublished} • Dokumen Terbuka untuk Nasabah & Publik`;
  if (pSummary) pSummary.textContent = file.summary;
  if (pPages) pPages.textContent = file.pages || 'Format PDF Resmi';

  const docUrl = file.filePath.startsWith('/') ? file.filePath : '/' + file.filePath;
  if (pIframe) {
    pIframe.src = `${docUrl}#toolbar=0&navpanes=0`;
  }
  if (pDownloadBtn) {
    pDownloadBtn.href = docUrl;
    pDownloadBtn.setAttribute('download', file.title.replace(/[^a-zA-Z0-9_-]/g, '_') + '.pdf');
  }
  if (pDownloadText) {
    pDownloadText.textContent = `Unduh PDF Resmi (${file.size})`;
  }
  if (pOpenTabBtn) {
    pOpenTabBtn.href = docUrl;
  }
}

function initLaporanPublikasi() {
  const searchInput = document.getElementById('laporan-search');
  const reportCards = document.querySelectorAll('.laporan-card');
  if (!searchInput || reportCards.length === 0) return;

  searchInput.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    reportCards.forEach(card => {
      const text = card.textContent.toLowerCase();
      if (!q || text.includes(q)) {
        card.classList.remove('hidden');
      } else {
        card.classList.add('hidden');
      }
    });
  });
}

/* ==========================================================================
   13. GLOBAL MODAL EVENT DELEGATION & SHORTCUTS
   ========================================================================== */
function initGlobalModals() {
  // Backdrop click dismissal for all modal elements
  const allModals = document.querySelectorAll('.modal-backdrop');
  allModals.forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
        const anyActive = document.querySelector('.modal-backdrop.active');
        if (!anyActive) {
          document.body.classList.remove('overflow-hidden');
        }
      }
    });
  });

  // ESC Key listener to close top active modal
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const activeModals = document.querySelectorAll('.modal-backdrop.active');
      if (activeModals.length > 0) {
        activeModals[activeModals.length - 1].classList.remove('active');
        if (activeModals.length === 1) {
          document.body.classList.remove('overflow-hidden');
        }
      }
    }
  });

  // Event delegation for data-open-pengajuan
  document.querySelectorAll('[data-open-pengajuan]').forEach(btn => {
    btn.addEventListener('click', () => {
      openFormPengajuan();
    });
  });

  // Event delegation for data-open-catalog
  document.querySelectorAll('[data-open-catalog]').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.openCatalog || 'all';
      openProductCatalog(cat);
    });
  });

  // Profile BPR modal close
  const profilClose = document.getElementById('modal-profil-close');
  if (profilClose) {
    profilClose.addEventListener('click', () => {
      const modal = document.getElementById('modal-profil-bpr');
      if (modal) modal.classList.remove('active');
      const anyActive = document.querySelector('.modal-backdrop.active');
      if (!anyActive) {
        document.body.classList.remove('overflow-hidden');
      }
    });
  }

  // Contact modal close
  const contactClose = document.getElementById('modal-kontak-close');
  if (contactClose) {
    contactClose.addEventListener('click', () => {
      const modal = document.getElementById('modal-kontak');
      if (modal) modal.classList.remove('active');
      const anyActive = document.querySelector('.modal-backdrop.active');
      if (!anyActive) {
        document.body.classList.remove('overflow-hidden');
      }
    });
  }
}

/* ==========================================================================
   14. POP-UP PERINGATAN WASPADA PENIPUAN (ANTI-FRAUD POPUP)
   ========================================================================== */
function initFraudWarningModal() {
  const modal = document.getElementById('modal-peringatan-penipuan');
  if (!modal) return;

  const closeBtn = document.getElementById('modal-peringatan-close');
  const dismissBtn = document.getElementById('modal-peringatan-dismiss');
  const learnBtn = document.getElementById('modal-peringatan-learn');

  const closeModal = () => {
    modal.classList.remove('active');
    const anyActive = document.querySelector('.modal-backdrop.active');
    if (!anyActive) {
      document.body.classList.remove('overflow-hidden');
    }
    try {
      sessionStorage.setItem('bpr_fraud_modal_dismissed', 'true');
    } catch (e) {}
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (dismissBtn) dismissBtn.addEventListener('click', closeModal);
  if (learnBtn) {
    learnBtn.addEventListener('click', () => {
      closeModal();
      if (typeof readArticle === 'function') {
        readArticle(3);
      }
    });
  }

  // Cek apakah ada query param ?popup=1 atau ?warning=1 untuk pengetesan langsung
  const urlParams = new URLSearchParams(window.location.search);
  const forceShow = urlParams.has('popup') || urlParams.has('warning');

  // Buka otomatis saat pertama kali dibuka pada sesi browsing
  try {
    const isDismissed = sessionStorage.getItem('bpr_fraud_modal_dismissed');
    if (!isDismissed || forceShow) {
      setTimeout(() => {
        const activeModal = document.querySelector('.modal-backdrop.active');
        if (!activeModal) {
          modal.classList.add('active');
          document.body.classList.add('overflow-hidden');
        }
      }, 700);
    }
  } catch (e) {
    setTimeout(() => {
      modal.classList.add('active');
      document.body.classList.add('overflow-hidden');
    }, 700);
  }
}

window.openFraudWarningModal = function() {
  const modal = document.getElementById('modal-peringatan-penipuan');
  if (modal) {
    modal.classList.add('active');
    document.body.classList.add('overflow-hidden');
  }
};

window.closeFraudWarningModal = function() {
  const modal = document.getElementById('modal-peringatan-penipuan');
  if (modal) {
    modal.classList.remove('active');
    const anyActive = document.querySelector('.modal-backdrop.active');
    if (!anyActive) {
      document.body.classList.remove('overflow-hidden');
    }
  }
};

// Global opener for BPR Profile modal (Sesuai Sketsa Halaman 11: "Kenali BPR ↗")
function openProfilBpr() {
  const modal = document.getElementById('modal-profil-bpr');
  if (modal) {
    modal.classList.add('active');
    document.body.classList.add('overflow-hidden');
  } else {
    const aboutSection = document.getElementById('tentang-kami');
    if (aboutSection) aboutSection.scrollIntoView({ behavior: 'smooth' });
  }
}

// Global opener for Contact Modal (Sesuai Sketsa Halaman 13: "Kontak ↗")
function openContactOptions() {
  const modal = document.getElementById('modal-kontak');
  if (modal) {
    modal.classList.add('active');
    document.body.classList.add('overflow-hidden');
  } else {
    window.open('https://wa.me/6281111116526', '_blank');
  }
}

/* ==========================================================================
   11. PENGADUAN NASABAH, ANTI-FRAUD CAPTCHA & STATUS TRACKING
   (Sesuai Kebutuhan Portal Pengaduan Resmi & Standar Perbankan)
   ========================================================================== */
function switchComplaintTab(tab) {
  const formContainer = document.getElementById('container-form-pengaduan');
  const trackContainer = document.getElementById('container-cek-pengaduan');
  const formBtn = document.getElementById('tab-btn-form-pengaduan');
  const trackBtn = document.getElementById('tab-btn-cek-pengaduan');

  if (tab === 'form') {
    if (formContainer) formContainer.classList.remove('hidden');
    if (trackContainer) trackContainer.classList.add('hidden');
    if (formBtn) {
      formBtn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm bg-bpr-navy text-white';
    }
    if (trackBtn) {
      trackBtn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all bg-white text-slate-700 hover:bg-slate-100 border border-slate-200';
    }
  } else {
    if (formContainer) formContainer.classList.add('hidden');
    if (trackContainer) trackContainer.classList.remove('hidden');
    if (trackBtn) {
      trackBtn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm bg-bpr-navy text-white';
    }
    if (formBtn) {
      formBtn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all bg-white text-slate-700 hover:bg-slate-100 border border-slate-200';
    }
  }
}

function copyComplaintCode() {
  const codeEl = document.getElementById('result-ticket-code');
  if (!codeEl) return;
  const code = codeEl.textContent.trim();

  const showCopyFeedback = () => {
    const copyText = document.getElementById('copy-text');
    if (copyText) {
      const orig = copyText.textContent;
      copyText.textContent = 'Tersalin! ✓';
      setTimeout(() => { copyText.textContent = orig; }, 2000);
    }
  };

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(code).then(() => {
      showCopyFeedback();
    }).catch(() => {
      const ta = document.createElement('textarea');
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      showCopyFeedback();
    });
  } else {
    const ta = document.createElement('textarea');
    ta.value = code;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showCopyFeedback();
  }
}

function resetComplaintForm() {
  const form = document.getElementById('form-pengaduan-nasabah');
  if (form) form.reset();
  const successBox = document.getElementById('complaint-success-result');
  if (successBox) successBox.classList.add('hidden');
  refreshComplaintCaptcha();
  const formSection = document.getElementById('pengaduan-nasabah');
  if (formSection) formSection.scrollIntoView({ behavior: 'smooth' });
}

function refreshComplaintCaptcha() {
  const questionEl = document.getElementById('complaint-captcha-question');
  const tokenInput = document.getElementById('complaint-captcha-token');
  const loadTokenInput = document.getElementById('complaint-form-load-token');
  const answerInput = document.getElementById('complaint-captcha-answer');

  if (answerInput) answerInput.value = '';

  const fallbackLocalCaptcha = () => {
    const n1 = Math.floor(Math.random() * 8) + 3;
    const n2 = Math.floor(Math.random() * 6) + 2;
    currentComplaintLocalAnswer = n1 + n2;
    if (questionEl) questionEl.textContent = `${n1} + ${n2} = ?`;
    if (tokenInput) tokenInput.value = `local_${currentComplaintLocalAnswer}`;
    if (loadTokenInput && !loadTokenInput.value) loadTokenInput.value = 'local_load_token';
  };

  // If question element is empty or says "Memuat...", generate local challenge immediately so it never hangs
  if (questionEl && (!questionEl.textContent || questionEl.textContent.includes('Memuat'))) {
    fallbackLocalCaptcha();
  }

  // Attempt to fetch fresh signed CAPTCHA from server with 3-second timeout
  let controller = null;
  let timeoutId = null;
  try {
    if (typeof AbortController !== 'undefined') {
      controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), 3000);
    }
  } catch (e) {}

  fetch('/captcha/generate', {
    headers: { 'Accept': 'application/json' },
    signal: controller ? controller.signal : undefined
  })
    .then(res => {
      if (timeoutId) clearTimeout(timeoutId);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    })
    .then(res => {
      if (res && res.success && res.data) {
        if (questionEl) questionEl.textContent = res.data.question;
        if (tokenInput) tokenInput.value = res.data.captcha_token;
        if (loadTokenInput) loadTokenInput.value = res.data.form_load_token;
        currentComplaintLocalAnswer = null; // server will verify
      } else {
        fallbackLocalCaptcha();
      }
    })
    .catch(() => {
      if (timeoutId) clearTimeout(timeoutId);
      fallbackLocalCaptcha();
    });
}

function checkStatusFromCode(code) {
  switchComplaintTab('track');
  const input = document.getElementById('track-ticket-code');
  if (input) {
    input.value = code;
    doFetchComplaintStatus(code);
  }
}

function handleCekStatusSubmit(event) {
  if (event) event.preventDefault();
  const input = document.getElementById('track-ticket-code');
  if (!input) return;
  const code = input.value.trim();
  if (!code) {
    alert('Silakan masukkan nomor kode unik pengaduan Anda.');
    input.focus();
    return;
  }
  doFetchComplaintStatus(code);
}

function renderTrackResultCard(d) {
  const card = document.getElementById('track-result-card');
  if (!card) return;
  card.classList.remove('hidden');

  const codeEl = document.getElementById('track-result-code');
  const badgeEl = document.getElementById('track-result-badge');
  const namaEl = document.getElementById('track-result-nama');
  const katEl = document.getElementById('track-result-kategori');
  const tglEl = document.getElementById('track-result-tanggal');
  const notesEl = document.getElementById('track-result-notes');

  if (codeEl) codeEl.textContent = d.ticket_code;
  if (namaEl) namaEl.textContent = d.nama;
  if (katEl) katEl.textContent = d.kategori;
  if (tglEl) tglEl.textContent = d.tanggal_lapor ? `${d.tanggal_lapor} WIB` : (d.tanggal || 'Baru Saja');
  if (notesEl) notesEl.textContent = d.catatan_petugas || 'Laporan pengaduan telah diterima dalam sistem terintegrasi Bank Majalengka dan sedang diteliti oleh Satuan Kerja Manajemen Risiko & Kepatuhan.';

  if (badgeEl) {
    badgeEl.textContent = d.status_label || 'Sedang Diproses';
    if (d.status === 'selesai') {
      badgeEl.className = 'px-3 py-1 rounded-full text-xs font-extrabold uppercase bg-emerald-100 text-emerald-800 border border-emerald-300';
    } else if (d.status === 'ditindaklanjuti') {
      badgeEl.className = 'px-3 py-1 rounded-full text-xs font-extrabold uppercase bg-blue-100 text-blue-800 border border-blue-300';
    } else {
      badgeEl.className = 'px-3 py-1 rounded-full text-xs font-extrabold uppercase bg-amber-100 text-amber-800 border border-amber-300';
    }
  }

  card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function doFetchComplaintStatus(code) {
  const btn = document.getElementById('track-submit-btn');
  const card = document.getElementById('track-result-card');
  const origBtnText = btn ? btn.textContent : '';

  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Mencari...';
  }

  fetch(`/pengaduan/status?code=${encodeURIComponent(code)}`, {
    headers: { 'Accept': 'application/json' }
  })
  .then(res => res.json().then(data => ({ ok: res.ok, data })))
  .then(({ ok, data }) => {
    if (btn) {
      btn.disabled = false;
      btn.textContent = origBtnText;
    }

    if (!ok || !data.success) {
      // Check local storage fallback before showing not found alert
      try {
        const stored = JSON.parse(localStorage.getItem('bank_majalengka_complaints') || '{}');
        if (stored[code]) {
          renderTrackResultCard(stored[code]);
          return;
        }
      } catch (e) {}

      alert(data?.message || 'Pengaduan dengan kode tiket tersebut tidak ditemukan. Mohon periksa kembali kode unik Anda.');
      if (card) card.classList.add('hidden');
      return;
    }

    renderTrackResultCard(data.data);
  })
  .catch(() => {
    if (btn) {
      btn.disabled = false;
      btn.textContent = origBtnText;
    }
    // Check local storage fallback on network failure
    try {
      const stored = JSON.parse(localStorage.getItem('bank_majalengka_complaints') || '{}');
      if (stored[code]) {
        renderTrackResultCard(stored[code]);
        return;
      }
    } catch (e) {}

    alert('Tidak dapat terhubung ke server pengaduan. Silakan periksa koneksi atau nomor tiket Anda.');
  });
}

function initPengaduanNasabah() {
  const form = document.getElementById('form-pengaduan-nasabah');
  if (!form) return;

  // Tab buttons click listeners
  const formTabBtn = document.getElementById('tab-btn-form-pengaduan');
  const trackTabBtn = document.getElementById('tab-btn-cek-pengaduan');
  if (formTabBtn) {
    formTabBtn.addEventListener('click', (e) => {
      e.preventDefault();
      switchComplaintTab('form');
    });
  }
  if (trackTabBtn) {
    trackTabBtn.addEventListener('click', (e) => {
      e.preventDefault();
      switchComplaintTab('track');
    });
  }

  const refreshBtn = document.getElementById('complaint-captcha-refresh');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', refreshComplaintCaptcha);
  }

  // Initialize CAPTCHA immediately
  refreshComplaintCaptcha();

  // Handle URL hash or param
  if (typeof window !== 'undefined' && window.location && (window.location.hash === '#cek-pengaduan' || (window.location.search && window.location.search.includes('code=')))) {
    const urlParams = new URLSearchParams(window.location.search || '');
    const codeParam = urlParams.get('code');
    if (codeParam) {
      setTimeout(() => {
        checkStatusFromCode(codeParam);
      }, 300);
    } else {
      switchComplaintTab('track');
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Check honeypot
    const honeypot = document.getElementById('complaint-honeypot');
    if (honeypot && honeypot.value.trim() !== '') {
      console.warn('Bot trap triggered');
      return;
    }

    const answerInput = document.getElementById('complaint-captcha-answer');
    if (!answerInput || !answerInput.value.trim()) {
      alert('Silakan isi jawaban verifikasi CAPTCHA keamanan.');
      if (answerInput) answerInput.focus();
      return;
    }

    // Verify local challenge if local challenge is active
    if (currentComplaintLocalAnswer !== null) {
      const parsedAns = parseInt(answerInput.value.trim(), 10);
      if (parsedAns !== currentComplaintLocalAnswer) {
        alert('Jawaban verifikasi Anti-Fraud belum tepat. Silakan hitung kembali.');
        answerInput.focus();
        return;
      }
    }

    const submitBtn = document.getElementById('complaint-submit-btn');
    const spinner = document.getElementById('complaint-submit-spinner');
    const submitText = document.getElementById('complaint-submit-text');

    if (submitBtn) submitBtn.disabled = true;
    if (spinner) spinner.classList.remove('hidden');
    if (submitText) submitText.textContent = 'Memverifikasi & Mengirim...';

    const formData = new FormData(form);

    fetch('/pengaduan', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
      },
      body: formData
    })
    .then(res => res.json().then(data => ({ ok: res.ok, status: res.status, data })))
    .then(({ ok, data }) => {
      if (submitBtn) submitBtn.disabled = false;
      if (spinner) spinner.classList.add('hidden');
      if (submitText) submitText.textContent = 'Kirim Pengaduan Nasabah';

      if (!ok || !data.success) {
        alert(data.message || 'Pengiriman pengaduan gagal. Silakan periksa kembali formulir Anda.');
        refreshComplaintCaptcha();
        return;
      }

      // Success: Reveal unique code card right below the form!
      const resultBox = document.getElementById('complaint-success-result');
      const ticketCodeEl = document.getElementById('result-ticket-code');
      const emailEl = document.getElementById('result-email-text');
      const emailNoticeEl = document.getElementById('result-email-notice');
      const bankEmailNoticeEl = document.getElementById('result-bank-email-notice');

      if (ticketCodeEl) ticketCodeEl.textContent = data.data.ticket_code;
      if (emailEl) {
        emailEl.textContent = data.data.email;
        emailEl.className = data.data.email_notified ? 'text-bpr-navy' : 'font-bold text-amber-700';
      }
      if (emailNoticeEl) {
        const applicantNotice = data.data.email_notified
          ? 'Tanda terima telah dikirim ke email: '
          : 'Tanda terima belum berhasil dikirim ke email: ';
        const bankNotice = data.data.bank_email_notified
          ? 'Notifikasi pengaduan juga telah dikirim ke bank.'
          : 'Notifikasi bank belum berhasil dikirim.';
        emailNoticeEl.firstChild.textContent = `${applicantNotice}`;
        emailNoticeEl.setAttribute('aria-label', `${applicantNotice}${data.data.email}. ${bankNotice}`);
        if (bankEmailNoticeEl) bankEmailNoticeEl.textContent = bankNotice;
      }

      if (resultBox) {
        resultBox.classList.remove('hidden');
        resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }

      form.reset();
      refreshComplaintCaptcha();
    })
    .catch(() => {
      if (submitBtn) submitBtn.disabled = false;
      if (spinner) spinner.classList.add('hidden');
      if (submitText) submitText.textContent = 'Kirim Pengaduan Nasabah';
      alert('Tidak dapat terhubung ke server. Pengaduan belum dapat dikonfirmasi; silakan coba kembali.');
    });
  });
}
